-- MySQL dump 10.13  Distrib 5.1.56, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: bmasite_visitors
-- ------------------------------------------------------
-- Server version	5.1.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `msg_id_fk` int(11) DEFAULT NULL,
  `u_id` smallint(5) unsigned DEFAULT NULL,
  `dtandtime` datetime NOT NULL,
  PRIMARY KEY (`com_id`),
  KEY `msg_id_fk` (`msg_id_fk`)
) ENGINE=MyISAM AUTO_INCREMENT=224 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (134,NULL,'Thanks Marie! :-)			',329,117,'2011-09-11 13:32:06'),(132,NULL,'		dsfgdfsd	',303,157,'2011-09-10 19:44:04'),(135,NULL,'	Gary,\nPhil wrote a comment yesterday to you, but do not see it here.\nKatie 		',332,124,'2011-09-12 07:16:05'),(141,NULL,'Yes, Gary and I will be there. Thanks again for the invite.			',336,118,'2011-09-12 15:01:58'),(151,NULL,'	thank you volkswagon - the intermediate bike trail is great fun 3miles 		',347,117,'2011-09-20 15:06:57'),(147,NULL,'today we did harrison bay and it was four and a half miles of pure fun 			',347,117,'2011-09-20 15:02:17'),(148,NULL,'for me its like flying - always different ',347,117,'2011-09-20 15:02:44'),(152,NULL,'As we remember 911, it also reminds us what a privilege it is to fly general aviation in the United States 			',313,117,'2011-09-20 15:09:17'),(153,NULL,'More than just today, the lingering effects were amplified during our recent trip to Groton in the Bonanza',313,117,'2011-09-20 15:09:54'),(156,NULL,'Ok need to explain a bit - each resident keeps theirs uptodate :-)			',356,117,'2011-09-20 16:08:52'),(157,NULL,'that is also the account settings button in the menu above			',358,117,'2011-09-20 16:12:11'),(158,NULL,'	Marie and I tried to seed the list to get things started		',356,117,'2011-09-20 16:12:56'),(159,NULL,'Next time we come over we ll seed some more if resident owners are missing :)			',356,117,'2011-09-20 16:16:07'),(160,NULL,'Yes.\n			',359,118,'2011-09-20 16:34:24'),(164,NULL,'	Let us know if we can be of any assistance in the unpacking?		',372,118,'2011-10-10 20:14:37'),(165,NULL,'	...or to work in the back room on the computer!		',373,117,'2011-10-11 11:34:16'),(166,NULL,'Yep better send it to mariesartwork - i just looked and couldnt find it 			',374,117,'2011-10-11 13:49:33'),(167,NULL,'	people need to update their own phone numbers katie		',378,117,'2011-10-11 18:21:08'),(170,NULL,'if you select \"main/entree\" and put in keyword \"breakfast\"		',381,117,'2011-10-12 08:38:15'),(178,NULL,'Playing dodge ball with the clouds!			',397,118,'2011-10-23 18:02:36'),(185,NULL,'play with the buttons at the bottom		',402,117,'2011-10-25 19:10:25'),(186,NULL,'click \"fullscreen\"',402,117,'2011-10-25 19:10:40'),(187,NULL,'click the uparrow way to the bottom left',402,117,'2011-10-25 19:11:00'),(188,NULL,'click the pause slide show',402,117,'2011-10-25 19:11:19'),(189,NULL,'move your cursor to the left middle of the image and youll see a left and right button',402,117,'2011-10-25 19:11:52'),(191,NULL,':-) if you pull the throttle back less than a thousand rpm with the gear up a horn will sound',403,117,'2011-10-27 18:21:51'),(193,NULL,'	its hard to slow the thing down, so coming into the pattern you pull the throttle back		',403,117,'2011-10-28 05:27:39'),(197,NULL,'	Either Bertrand is willing to serve.  		',411,179,'2011-11-02 13:37:46'),(198,NULL,'			Thank you for stepping up to serve.  ',411,124,'2011-11-02 18:53:57'),(200,NULL,'	fantastic!		',418,184,'2011-11-11 15:03:18'),(210,NULL,'edit feature not written yet - just make a new comment and delete the old one			',443,184,'2011-12-06 07:56:01'),(221,NULL,'edit feature now available!			',443,184,'2011-12-31 12:00:43'),(220,NULL,'Created a community project for this subject			',446,184,'2011-12-16 08:08:02'),(222,NULL,'Home > Community Projects, Initiatives, and Proposals			',458,117,'2012-01-10 07:54:20'),(223,NULL,'When you select a project you must scroll down below edit window to see	',458,117,'2012-01-10 08:37:03');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `initiative2012budgetresidentsvote137`
--

DROP TABLE IF EXISTS `initiative2012budgetresidentsvote137`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `initiative2012budgetresidentsvote137` (
  `voterid` smallint(5) unsigned DEFAULT NULL,
  `vote` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `votecomment` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datevoted` int(10) unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `initiative2012budgetresidentsvote137`
--

LOCK TABLES `initiative2012budgetresidentsvote137` WRITE;
/*!40000 ALTER TABLE `initiative2012budgetresidentsvote137` DISABLE KEYS */;
INSERT INTO `initiative2012budgetresidentsvote137` VALUES (1,'no','budget proposal should include mower shed',1323193464),(2,'none','',1323193320),(3,'none','',1323193320),(4,'none','',1323193320),(5,'none','',1323193320),(6,'none','',1323193320),(7,'none','',1323193320),(8,'none','',1323193320),(9,'none','',1323193320),(10,'none','',1323193320),(11,'none','',1323193320),(12,'none','',1323193320),(13,'none','',1323193320);
/*!40000 ALTER TABLE `initiative2012budgetresidentsvote137` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `initiativeMissionboardvote136`
--

DROP TABLE IF EXISTS `initiativeMissionboardvote136`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `initiativeMissionboardvote136` (
  `voterid` smallint(5) unsigned DEFAULT NULL,
  `vote` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `votecomment` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datevoted` int(10) unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `initiativeMissionboardvote136`
--

LOCK TABLES `initiativeMissionboardvote136` WRITE;
/*!40000 ALTER TABLE `initiativeMissionboardvote136` DISABLE KEYS */;
INSERT INTO `initiativeMissionboardvote136` VALUES (1,'yes','Please see \"Vision Statement\" Project for updates',1323346627),(2,'none','',1322619550),(5,'none','',1322619550),(8,'none','',1322619550);
/*!40000 ALTER TABLE `initiativeMissionboardvote136` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `initiativeMowPlan2012residentsvote134`
--

DROP TABLE IF EXISTS `initiativeMowPlan2012residentsvote134`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `initiativeMowPlan2012residentsvote134` (
  `voterid` smallint(5) unsigned DEFAULT NULL,
  `vote` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `votecomment` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datevoted` int(10) unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `initiativeMowPlan2012residentsvote134`
--

LOCK TABLES `initiativeMowPlan2012residentsvote134` WRITE;
/*!40000 ALTER TABLE `initiativeMowPlan2012residentsvote134` DISABLE KEYS */;
INSERT INTO `initiativeMowPlan2012residentsvote134` VALUES (1,'none','',1321747525),(2,'none','',1321747525),(3,'none','',1321747525),(4,'none','',1321747525),(5,'none','',1321747525),(6,'none','',1321747525),(7,'none','',1321747525),(8,'none','',1321747525),(9,'none','',1321747525),(10,'none','',1321747525),(11,'none','',1321747525),(12,'none','',1321747525);
/*!40000 ALTER TABLE `initiativeMowPlan2012residentsvote134` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `initiativePondimprovementresidentsvote133`
--

DROP TABLE IF EXISTS `initiativePondimprovementresidentsvote133`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `initiativePondimprovementresidentsvote133` (
  `voterid` smallint(5) unsigned DEFAULT NULL,
  `vote` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `votecomment` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datevoted` int(10) unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `initiativePondimprovementresidentsvote133`
--

LOCK TABLES `initiativePondimprovementresidentsvote133` WRITE;
/*!40000 ALTER TABLE `initiativePondimprovementresidentsvote133` DISABLE KEYS */;
INSERT INTO `initiativePondimprovementresidentsvote133` VALUES (1,'yes','Please support this initiative!',1321051631),(2,'none','',1321050911),(3,'none','',1321050911),(4,'none','',1321050911),(5,'none','',1321050911),(6,'none','',1321050911),(7,'none','',1321050911),(8,'none','',1321050911),(9,'none','',1321050911),(10,'none','',1321050911),(11,'none','',1321050911),(12,'none','',1321050911);
/*!40000 ALTER TABLE `initiativePondimprovementresidentsvote133` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `initiativemowershedresidentsvote149`
--

DROP TABLE IF EXISTS `initiativemowershedresidentsvote149`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `initiativemowershedresidentsvote149` (
  `voterid` smallint(5) unsigned DEFAULT NULL,
  `vote` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `votecomment` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datevoted` int(10) unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `initiativemowershedresidentsvote149`
--

LOCK TABLES `initiativemowershedresidentsvote149` WRITE;
/*!40000 ALTER TABLE `initiativemowershedresidentsvote149` DISABLE KEYS */;
INSERT INTO `initiativemowershedresidentsvote149` VALUES (1,'yes','Clubhouse update1',1325858389),(2,'none','',1325275042),(3,'none','',1325275042),(4,'none','',1325275042),(5,'none','',1325275042),(6,'none','',1325275042),(7,'none','',1325275042),(8,'none','',1325275042),(9,'none','',1325275042),(10,'none','',1325275042),(11,'none','',1325275042),(12,'none','',1325275042),(13,'none','',1325275042);
/*!40000 ALTER TABLE `initiativemowershedresidentsvote149` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `initiatives`
--

DROP TABLE IF EXISTS `initiatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `initiatives` (
  `iid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `iname` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `shortdesc` varchar(160) COLLATE utf8_unicode_ci NOT NULL,
  `abstract` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  `volunteerc` tinyint(4) NOT NULL,
  `chairrec` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `resdecide` tinyint(4) DEFAULT NULL,
  `voteid` smallint(5) DEFAULT NULL,
  `istatus` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `duration` smallint(5) unsigned NOT NULL,
  `treopened` smallint(5) unsigned NOT NULL,
  `whoreopened` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `descname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `proposalreq` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `datetimeopened` int(10) unsigned DEFAULT NULL,
  `datetimereopened` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`iid`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `initiatives`
--

LOCK TABLES `initiatives` WRITE;
/*!40000 ALTER TABLE `initiatives` DISABLE KEYS */;
INSERT INTO `initiatives` VALUES (143,'Provide a shed for landscaping equipment','We need a building to put all lawnmowers and tools at BMA.','Katie and Phil are wanting to be relieved of the mowers.  They have housed and maintained these mowers for going on five years and would really appreciatre it if we can come to some decisions as they are planning projects in their hangar and are in need of the space that the mowers currently house.','Marie House',118,0,'Phil Dater',1,149,'open',60,0,'117','mowershed','*any building will have to house two zero turn lawnmowers and equipment\r\n*big enough to accomodate maintenance on mowers\r\n*access power \r\n*access water\r\n*cost\r\n*location\r\n*waiting on Phil to get additonal requirements for this proposal.',1321048551,1325275042),(144,'Preservation of BMA Pond and Surrounding','Our vision for the BMA pond and surrounding area','I want to see future generations being able to fish, hike, bike and run.\r\nObserve local birds and butterflies and encourage blue heron to visit every year. Let\'s maintain BMA pond and surrounding area like a wildlife refuge. Fish fries to promote good will to our neighbors and possibly raise funds for future initiatives in the future. ','Marie House',118,1,'none',1,133,'open',120,0,'','Pondimprovement','Any proposal should include the following:\r\n1. How we will insure the pristine beauty of BMA pond and surrouding community \r\n2. How we can insure that we will have fish for fishing. Ex. No unneccessary cutting of trees, putting chemicals in pond or fish that could be dangerous for future fish to inhabit the pond.\r\nPlanting wild grasses that encourage butterflies and beautiful birds.\r\n3. Keeping hi',1321050911,NULL),(145,'BMA mowing plan 2012','Organize a mowing strategy for 2012','BMA mowing involves three items, 1) anticipating the next mow (landscape management), 2) doing the actual mowing (mowing resource), and 3) maintaining the mowing equipment (equipment maintenance). Through 2011, Phil and Katie did all of 1 and 3, and shared 2 with other residents in the airpark. In 2012 they would like to continue 2 and 3 as is, but eliminate 1, which ties them to the airpark full time during the mowing season. BMA residents like a \"shared approach\" for number 2, the mowing resource, because mowing equipment is available, it allows them to reduce their monthly dues, and keeps the cost down. However, doing 2 only solves part of the problem. Inaccurate landscape management can be costly in time and hard on the equipment. Thus some residents want a more organized approach which involves outsourcing the work. So far though, outsourcing alternatives have only addressed 2, the mowing resource. We must also consider liability. Outsourcing must consider insurance or an insurance waver.','Gary Gross',117,1,'none',1,134,'open',60,0,'','MowPlan2012','For 2012, any proposal should include a solution for 1)landscape management,  2) the mowing resource. Cost, quality, reliability, and insurance or ins waiver should also be addressed. ',1321747525,NULL),(147,'Mission Statement','Mission Statement','The Mission Statement is a top-level statement that will be used to guide the Board in future decisions that affect all owners.  Owners are encouraged to review and provide comments prior to the annual meeting.','daniel budde',127,1,'none',0,136,'open',90,0,'','Mission','\"Blue Mountain Air Park is a rural aviation-oriented community where owners and guests can pursue the joy of flying and aviation related activities in a fun and safe environment.  Our core values show pride of ownership without being flashy or extravagant because we believe that protects and enhances our property values and promotes a highly cohesive community\"',1322619550,NULL),(148,'2012 Budget','Placeholder for 2012 budget proposals','The budget is a bit more complicated for 2012 because a mower and tools shed is required.','Gary Gross',184,0,'Phil Dater',1,137,'open',120,0,'','2012budget','Proposals should accomodate the requirement for a new mower shed in addition to the other normal items',1323193320,NULL);
/*!40000 ALTER TABLE `initiatives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `message` varchar(200) DEFAULT NULL,
  `u_id` smallint(5) unsigned DEFAULT NULL,
  `dtandtime` datetime NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=460 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (356,NULL,'Gary: I checked the resident list and you may need to update. I sent Marie a new list yesterday. Thanks for all your work. Katie ',124,'2011-09-20 15:46:57'),(455,NULL,'Whew! http://www.youtube.com/watch?v=_lAu-HpzqM4',117,'2011-12-20 10:22:15'),(329,NULL,'Just want to tell you how excited I am about this Blue Mountain. Thank you Gary for your countless hours putting this website together for the future of Blue Mountain Airpark.',118,'2011-09-11 13:10:33'),(453,NULL,'How short can you get? http://freedom4um.com/cgi-bin/readart.cgi?ArtNum=133255',117,'2011-12-20 09:15:45'),(454,NULL,'Digital Nativity > http://www.youtube.com/watch?v=GkHNNPM7pJA',117,'2011-12-20 09:25:04'),(332,NULL,'Still having some issues with this new wall software - let me know if you have problems',117,'2011-09-12 03:37:40'),(333,NULL,'You can disable email notifications in your accout settings',117,'2011-09-12 03:57:41'),(334,NULL,'Gary,\nPhil wrote a comment yesterday, but do not see it here.\nKatie',124,'2011-09-12 07:15:54'),(335,NULL,'It is a beautiful day here at the Blue Mountain Airpark.',118,'2011-09-12 11:39:27'),(336,NULL,'Burgers at 6:30',124,'2011-09-12 13:36:42'),(359,NULL,'Gary: I am not sure what you mean. I am thinking that each person needs to update their own information. Is that correct? ',124,'2011-09-20 16:27:59'),(358,NULL,'You can make your resident info accurate for others to use at http://www.bluemountainairpark.com/Pub2/login/accountEdit.php',117,'2011-09-20 16:11:22'),(459,NULL,'scene artist > http://www.wimp.com/seenartist/',117,'2012-01-10 17:30:11'),(341,NULL,'Looks good...',154,'2011-09-12 21:07:30'),(346,NULL,'What a beautiful day we have been blessed with today!',118,'2011-09-14 10:28:52'),(456,NULL,'Oskosh 2011 > http://www.twaseniorsclub.org/Oshkosh.html',117,'2011-12-20 12:54:15'),(457,NULL,'PacX > http://liquidr.com/pacx/',117,'2011-12-27 16:54:59'),(458,NULL,'Hi, does everyone know how to get to projects to view updates to the BMA Vision Statement and Mower Shed? :-)',117,'2012-01-10 07:47:55'),(360,NULL,'WHEW! I just finished a 4 and half hour art lesson!!!! Betty is determined to do a painting of each of her granchildren.  We have 6 and half more to go!',118,'2011-09-20 16:35:20'),(352,NULL,'It is an exceptionally beautiful morning here at Blue Mountain.  The air is crisp and clean! The sky is a beautiful cobalt blue shade with some whispy white clouds',118,'2011-09-18 08:35:54'),(351,NULL,'I am so excited that Nancy and John moved in! Now we have more neighbors!  YEAH!!!!\n',118,'2011-09-18 08:32:48'),(354,NULL,'Check out the Black Beans and Rice recipe at \nhttp://www.bluemountainairpark.com/Pub2/login/recipebook/index.php?m=recipes',117,'2011-09-19 17:45:10'),(355,NULL,'hey did you know that you can get a printer friendly list of residents? http://www.bluemountainairpark.com/Pub2/login/listResidentsPF.php',117,'2011-09-20 14:54:42'),(362,NULL,'Now for a little reward. Headed to Don Lolo.  Any one want to come along let me know?',118,'2011-09-20 16:37:33'),(363,NULL,'WOW! What a delicious meal last night at Don Lolo.  It was fun having a double date with Katie and Phil.  I highly recommend the fajita salad!  YUMMY!',118,'2011-09-21 08:12:19'),(364,NULL,'I wish everyone at Blue Mountain Airpark a very \"HAPPY\" day.',118,'2011-09-21 08:13:14'),(365,NULL,'What a cooool morning here at Blue Mountain.  ',118,'2011-10-03 07:48:57'),(367,NULL,'crazy mountain bike ride at bookerTWashington today',117,'2011-10-04 20:22:25'),(368,NULL,'Anyone with ideas for a short breakfast flight (<30min)?',124,'2011-10-05 19:11:26'),(369,NULL,'Wow! Wish all the lot owners could be here to see how beautiful the runway looks.  Hope everyone is enjoying the Fall weather.\n',118,'2011-10-06 07:39:54'),(370,NULL,'Last nigh we saw Venus so brightly shining as well as the moon, it is so nice to live in Blue Mountain! Day or night! HA HA',118,'2011-10-06 07:40:55'),(371,NULL,'You now agree to the landing waver at the time you register with the BMA website',117,'2011-10-10 17:20:17'),(372,NULL,'The unpacking has begun.',179,'2011-10-10 19:04:29'),(373,NULL,'Rain, Rain, Rain--Beautiful day to paint in the hangar!',118,'2011-10-11 11:32:17'),(374,NULL,'Rain has been wonderful.\nGary, do you need the by-laws for the web page?\nKatie',124,'2011-10-11 13:39:17'),(376,NULL,'Betty and I had a FUN art lesson today. One painting down six more to go! She was happy to take the first painting home.  I am so glad I am able to teach!',118,'2011-10-11 16:14:49'),(378,NULL,'Many thanks Gary. They look good. I sent phone numbers to Marie for the web site as well. Katie',124,'2011-10-11 17:14:59'),(379,NULL,'Looking forward to seeing my Buncko girls this evening! Great laughs and gread fun!',118,'2011-10-12 06:58:27'),(384,NULL,'Gary  The numbers I sent are for the web site, useful information numbers such as tag office, post office etc. Katie ',124,'2011-10-12 12:08:39'),(386,NULL,'a few details on the potluck...this is to connect people who like to play music..you MUST bring and play an instrument (spouses get a free ride)',123,'2011-10-14 08:50:08'),(388,NULL,'I thank Alisa and Brent for such a wonderful gathering of music, friends and making new friends. Gary and I really enjoyed ourselves.  You two are the best!',118,'2011-10-18 11:11:28'),(390,NULL,'Thinking about a fire tonight, first of the season.\nDitto about Saturday night at the Bighams, wonderful evening.\nPhil and Katie',124,'2011-10-19 15:01:02'),(391,NULL,'It feels good being in my cozy home with a fire in the fireplace.  I feel much better today after being down for three days with my back.\n',118,'2011-10-19 17:17:59'),(392,NULL,'Marie, sorry to hear that your back was giving you trouble and glad you are cozy with your fire. We had a fire too, nice.\nKatie',124,'2011-10-19 20:35:35'),(393,NULL,'we had a fire too...also the 1st of the season.  what could be better than a fire on a brisk cold day?\n',123,'2011-10-19 22:13:45'),(395,NULL,'I am over the moon!!! Mike and Sara, Lauren, Nathan, and River are on their way to see me!  I am so very happy.',118,'2011-10-20 13:24:24'),(396,NULL,'We are excited for you Marie. You will have a full and happy house. The green tractor is in the hangar if you need it for the kids. Katie',124,'2011-10-20 19:14:09'),(397,NULL,'http://www.youtube.com/watch?v=d8RakYuiH24',118,'2011-10-23 17:40:54'),(400,NULL,'I love this new slideshow effect!  Thanks Gary.',118,'2011-10-25 16:46:00'),(401,NULL,'Very nice.  Can I make it larger?  And how about some photos of the other properties, too?',179,'2011-10-25 18:58:44'),(402,NULL,'More about the image viewer',117,'2011-10-25 19:10:01'),(405,NULL,'Love the pictures. Thanks to Gary and Marie for all your work on the web page, wonderful. Phil and Katie',124,'2011-10-28 08:37:50'),(406,NULL,'I agree!  Thanks for all you do. Nancy',179,'2011-10-28 08:41:01'),(408,NULL,'Get those fires burning because it is going to be really, really cold tonight!',118,'2011-10-28 17:58:44'),(409,NULL,'Sorry for the racket. The alarm man is here installing a new part and testing it.  Nancy',179,'2011-10-29 12:48:44'),(410,NULL,'I am so very THANKFUL for my friends, neighbors and family.  I am so very thankful you are in my life!!xoxoxo',118,'2011-11-02 13:31:36'),(411,NULL,'There is a flyin scheduled for November 19th!  Be there, should be fun for all.  Also a BMA Board mtg. following the flyin.  Do you want to serve on the Board, we sure could use some nominations.  Tha',118,'2011-11-02 13:32:58'),(412,NULL,'Beautiful day in the neighborhood! Many thanks for Bertrands stepping up to serve. Quinn had a great idea for the fly-in, a chili cook off so get your receipts out. Katie',124,'2011-11-02 13:46:20'),(413,NULL,'Rain, Rain, what a beautiful sound on the roof!',118,'2011-11-03 14:53:15'),(416,NULL,'What a beautiful warm day,  I am going to paint today!\n',118,'2011-11-08 09:29:27'),(418,NULL,'Take a look at the BMA pond and fall photos I uploaded.  You will enjoy I think?',118,'2011-11-11 13:08:07'),(421,NULL,'BRRRRRRR!! Need the fire in the fireplace today.',118,'2011-11-12 08:16:47'),(422,NULL,'Got Gary a early Christmas present in Cartersville Saturday. The flying boatman!  See if you can find him in the slide show.  I was hoping to show Quinn and Dianna the flying trike so they could get i',118,'2011-11-14 19:39:16'),(423,NULL,'Remember, see posting from 10-25 on how to upload your photos to the bluemountain website!',184,'2011-11-16 08:29:41'),(424,NULL,'Check out this spherical flying machine > http://www.wimp.com/sphericalmachine/\n',117,'2011-11-17 14:15:44'),(434,NULL,'People can now follow BMA on twitter - instructions on the home page when you re logged out',117,'2011-11-22 15:44:21'),(435,NULL,'Happy Thanksgiving and safe travels to all of our neighbors,family and friends.',118,'2011-11-23 08:03:31'),(436,NULL,'Happy Thanksgiving to all. Our son and family arrived this morning and the kites are now flying.',124,'2011-11-23 12:28:31'),(433,NULL,'Twitter FYI instructions here > http://www.bluemountainairpark.com/Pub2/login/htmlfiles/twitterhowto.htm ',117,'2011-11-22 15:42:54'),(432,NULL,'Wow, great pictures from the fly-in.  Many thanks to Marie and Gary. It wsa a great day and fun to work together. Phil and Katie',124,'2011-11-21 08:26:06'),(437,NULL,'Thanks Dan for attempting an initiative (and your patience) - there was a problem which i fixed  ',184,'2011-11-26 10:17:33'),(438,NULL,'We have had enough rain now--I was thinking I would need a conoe to get out of here! HA HA!\n',118,'2011-11-28 18:02:07'),(439,NULL,'Put another log on the fire tonight!  It is going down pretty cold!!!!',118,'2011-11-28 18:03:06'),(440,NULL,'What a beautiful day!',118,'2011-12-02 16:22:30'),(443,NULL,'Hey everybody we now have a new bma projects app >BMA http://www.bluemountainairpark.com/Pub2/login/Projects/commentfromproject.php',184,'2011-12-06 07:45:03'),(446,NULL,'Gary, The shed will be a one time expense to be voted on separately  and not part of the budget. The budget is for annual operating \nexpenses. If the shed is purchased with a loan, then loan payments ',124,'2011-12-06 13:57:38'),(451,NULL,'whoo hoo! solve the \"apostrophe\" problem :-) yep you can now use proper grammer >  \"you\'d\" now works!',184,'2011-12-08 05:55:17');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments44`
--

DROP TABLE IF EXISTS `projectcomments44`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments44` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments44`
--

LOCK TABLES `projectcomments44` WRITE;
/*!40000 ALTER TABLE `projectcomments44` DISABLE KEYS */;
INSERT INTO `projectcomments44` VALUES (1,44,'<p>New project, project name: BMA Vision Statement</p>',1323175468,'Gary Gross',117),(2,44,'<p>\r\n	Starting point:</p>\r\n<p>\r\n	Blue Mountain Air Park is a rural aviation-oriented community where owners and guests can pursue the joy of flying and aviation related activities in a fun and safe environment.&nbsp; Our core values show pride of ownership without being flashy or extravagant because we believe that protects and enhances our property values and promotes a highly cohesive community</p>\r\n',1323175513,'Gary Gross',117),(16,44,'<p>\r\n	<font face=\"Arial\" size=\"1\">&nbsp;</font>Blue Mountain Air Park is a <u>small</u>, rural aviation-oriented community where owners and guests can pursue the&nbsp;joy of flying and other activities in a fun and safe environment.&nbsp; Our core values&nbsp;include pride of ownership and attention to the longevity and sustainability of&nbsp;the&nbsp;airpark <u>by all working together in a communal spirit</u>, which will preserve our community for our generation and future generations to come.<span style=\"display: none\">&nbsp;</span></p>\r\n',1325447884,'Phil Dater',124),(7,44,'<p>\r\n	<font face=\"Arial\" size=\"1\">&nbsp;</font>Blue Mountain Air Park is a rural aviation-oriented community where owners and guests can pursue the&nbsp;joy of flying and other activities in a fun and safe environment.&nbsp; Our core values&nbsp;include pride of ownership and attention to the longevity and sustainability of&nbsp;the&nbsp;airpark, which will preserve our community for our generation and future generations to come.<span style=\"display: none\">&nbsp;</span></p>\r\n',1325276518,'Marie House',118);
/*!40000 ALTER TABLE `projectcomments44` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments45`
--

DROP TABLE IF EXISTS `projectcomments45`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments45` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments45`
--

LOCK TABLES `projectcomments45` WRITE;
/*!40000 ALTER TABLE `projectcomments45` DISABLE KEYS */;
INSERT INTO `projectcomments45` VALUES (1,45,'<p>New project, project name: Mower Shed Backyard Outfitters</p>',1323186577,'Marie House',118),(2,45,'<p>\r\n	Talking with Phil and Katie last night, we discussed how we could expand the original proposal to accomodate both the large and small mowers by making the building longer and including a garage door on the end.&nbsp;&nbsp;This would increase the price, but our thinking is that this could still be within budget.&nbsp; &nbsp;</p>\r\n',1323186738,'Marie House',118),(6,45,'<p>\r\n	Phil I just wanted to confirm with you that the 12x24 with garage door will fit both mowers?</p>\r\n',1325522905,'Marie House',118),(4,45,'<p>\r\n	<font face=\"Arial\" size=\"1\">&nbsp;</font></p>\r\n<p>\r\n	This raised questions regarding the 2012 budget, and whether the expense will be handled as a one-time-expense, or within the yearly budget like the mowers are handled (as a loan).<span style=\"display: none\">&nbsp;</span></p>\r\n',1323214026,'Gary Gross',184),(26,45,'<p>\r\n	I have updated the Initiative,</p>\r\n<table border=\"1\" cellpadding=\"7\" id=\"table1\" style=\"border-collapse: collapse\" width=\"bwidth%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				<font color=\"#000000\" face=\"arial\" size=\"1\"><a href=\"http://www.bluemountainairpark.com/Pub2/login/Initiatives/ShowInitiativeDetail.php?iid=143\">Provide a shed for landscaping equipment</a></font></td>\r\n			<td>\r\n				<font color=\"#000000\" face=\"arial\" size=\"1\"></font></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	with a new proposal that includes our most recent cost information, and I encourage our community members to vote on-line (with your comments) on this new proposal.&nbsp;Our current target for making a decision on this shed, is the January 14th board meeting.</p>\r\n<p>\r\n	Remember, you can find&nbsp;and vote on the initiative&nbsp;by logging into the BMA Website (which takes you straight to the News Page &gt; <a href=\"http://www.bluemountainairpark.com/Pub2/login/news.php\">BMA News Page</a>). When you vote be sure to include a comment which describes the proposal that you support!</p>\r\n',1325858290,'Marie House',118),(23,45,'<p>\r\n	<font face=\"Arial\" size=\"1\">&nbsp;</font>Received an update with new information. 12x24 Side Lofted Barn Cabin with added garage door (9x7) on one end will cost</p>\r\n<p>\r\n	$5,660.00 with $396.20 Georgia Sales Tax.&nbsp; Toal being: $6,056.20.&nbsp; Free delivery<span style=\"display: none\">&nbsp;</span></p>\r\n',1325554409,'Marie House',118),(27,45,'<p>\r\n	We&#39;ve uploaded Phil Dater&#39;s latest design for the proposed mower shed (mshedupdt2.jpg) on this page.</p>\r\n',1326490238,'Marie House',118);
/*!40000 ALTER TABLE `projectcomments45` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments46`
--

DROP TABLE IF EXISTS `projectcomments46`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments46` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments46`
--

LOCK TABLES `projectcomments46` WRITE;
/*!40000 ALTER TABLE `projectcomments46` DISABLE KEYS */;
INSERT INTO `projectcomments46` VALUES (1,46,'<p>New project, project name: 2012 Budget Discussions</p>',1323214539,'Gary Gross',184),(2,46,'<p>\r\n	This discussion started when Marie voted &quot;no&quot; on the initiative to finalize the 2012 budget, when the only proposal on the table did not include the mower shed.</p>\r\n',1323214714,'Gary Gross',184),(3,46,'<p>\r\n	On the wall, the Daters reminded Marie and Gary that the shed will be a one time expense to be voted on separately and not part of the budget. The budget is for annual operating expenses. If the shed is purchased with a loan, then loan payments.</p>\r\n',1323214894,'Gary Gross',184),(14,46,'<p>\r\n	<span style=\"font-size: 11px\"><font face=\"Arial\">Marie feels&nbsp;this is important because it is her</font>&nbsp;responsibility to further explore the other open project here, &quot;Mower Shed Backyard Outfitters&quot; - then come up with a realistic number.</span></p>\r\n',1324044016,'Gary Gross',184),(7,46,'<p>\r\n	This is important to us because it s our responsibility to further explore the other open project here, &quot;Mower Shed Backyard Outfitters&quot; - now that we have expanded that idea - then come up with a realistic number.</p>\r\n',1323216917,'Gary Gross',184),(8,46,'<p>\r\n	<font face=\"Arial\" size=\"1\">&nbsp;</font>Marie&nbsp;is thinking along the lines, *a budget* - an amount of money available and set aside for a specific purpose over a designated period of time&quot; - like &quot;how much money available for the mower shed&quot;, &quot;can we afford to blow the whole savings on a mower shed?&quot; - &quot;are there other immediate concerns like road repairs&quot;? The last savings account number we saw was around July of this year - and the number we remember would be pretty much consumed by a one-time-expense?</p>\r\n',1324030335,'Gary Gross',184),(12,46,'<p>\r\n	Since the mower is a loan, and included as part of the annual budget,&nbsp;Marie is&nbsp;thinking this could be the case - or a possibility for the mower shed as well.</p>\r\n',1324043520,'Gary Gross',184),(13,46,'<p>\r\n	<span style=\"font-size: 11px\"><font face=\"Arial\">Marie has</font>&nbsp;temporarily voted &quot;no&quot; to the current budget because&nbsp;she doesn&#39;t&nbsp;have a handle on the &quot;total money requred&quot; for next year, etc<span style=\"display: none\">&nbsp;<span style=\"display: none\">&nbsp;</span></span></span></p>\r\n',1324043714,'Gary Gross',184);
/*!40000 ALTER TABLE `projectcomments46` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments47`
--

DROP TABLE IF EXISTS `projectcomments47`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments47` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments47`
--

LOCK TABLES `projectcomments47` WRITE;
/*!40000 ALTER TABLE `projectcomments47` DISABLE KEYS */;
INSERT INTO `projectcomments47` VALUES (1,47,'<p>New project, project name: Ahrens Projects</p>',1325423685,'Gary Gross',117);
/*!40000 ALTER TABLE `projectcomments47` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments48`
--

DROP TABLE IF EXISTS `projectcomments48`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments48` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments48`
--

LOCK TABLES `projectcomments48` WRITE;
/*!40000 ALTER TABLE `projectcomments48` DISABLE KEYS */;
INSERT INTO `projectcomments48` VALUES (1,48,'<p>New project, project name: Bertrand\'s Projects</p>',1325425910,'Gary Gross',117);
/*!40000 ALTER TABLE `projectcomments48` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments50`
--

DROP TABLE IF EXISTS `projectcomments50`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments50` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments50`
--

LOCK TABLES `projectcomments50` WRITE;
/*!40000 ALTER TABLE `projectcomments50` DISABLE KEYS */;
INSERT INTO `projectcomments50` VALUES (1,50,'<p>New project, project name: BMA Water Line Expansion (Brent) </p>',1326211569,'Gary Gross',117),(2,50,'<p>\r\n	Gary is just moving project information from another location to this more convenient spot.</p>\r\n<p>\r\n	Information on file:</p>\r\n<p>\r\n	Files and comments received from Philip on 12/08/2010:</p>\r\n<ul>\r\n	<li>\r\n		We have no textual description of the project, so scheduling and impact are not well understood at this point</li>\r\n</ul>\r\n',1326217092,'Gary Gross',117);
/*!40000 ALTER TABLE `projectcomments50` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments51`
--

DROP TABLE IF EXISTS `projectcomments51`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments51` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments51`
--

LOCK TABLES `projectcomments51` WRITE;
/*!40000 ALTER TABLE `projectcomments51` DISABLE KEYS */;
INSERT INTO `projectcomments51` VALUES (1,51,'<p>New project, project name: BMA Community Income Sources</p>',1326219040,'Gary Gross',117);
/*!40000 ALTER TABLE `projectcomments51` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments52`
--

DROP TABLE IF EXISTS `projectcomments52`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments52` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments52`
--

LOCK TABLES `projectcomments52` WRITE;
/*!40000 ALTER TABLE `projectcomments52` DISABLE KEYS */;
INSERT INTO `projectcomments52` VALUES (1,52,'<p>New project, project name: BMA Maintenance Quality Standards</p>',1326219312,'Gary Gross',117),(2,52,'<p>\r\n	Gary just moved the current table to this more convenient location.</p>\r\n<p>\r\n	See the project file mainquality1.htm for the detail&nbsp;</p>\r\n',1326219574,'Gary Gross',117);
/*!40000 ALTER TABLE `projectcomments52` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments53`
--

DROP TABLE IF EXISTS `projectcomments53`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments53` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments53`
--

LOCK TABLES `projectcomments53` WRITE;
/*!40000 ALTER TABLE `projectcomments53` DISABLE KEYS */;
INSERT INTO `projectcomments53` VALUES (1,53,'<p>New project, project name: Homeowner Businesses at BMA</p>',1326395851,'Gary Gross',117),(2,53,'<p>\r\n	It&#39;s our understanding that we have the opportunity to vote on adjusting the BMA Covenants to make homeowner businesses at BMA comply with Walker County rules.</p>\r\n<p>\r\n	We have uploaded the Walker rules for resident review.</p>\r\n<p>\r\n	If you look at rule #1 you will see right away, that some of us may already be in violation of this new proposed ruling for BMA (we think this means you can&#39;t have people come in and work for you at your house):</p>\r\n<p style=\"margin-left: 77pt\">\r\n	<strong>(1)</strong></p>\r\n<p style=\"margin-left: 113pt\">\r\n	No persons, other than those residing on the premises, shall be engaged in such occupation;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	We believe that we could be moving too fast on this and should discuss the issue further.</p>\r\n',1326396438,'Marie House',118);
/*!40000 ALTER TABLE `projectcomments53` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments55`
--

DROP TABLE IF EXISTS `projectcomments55`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments55` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments55`
--

LOCK TABLES `projectcomments55` WRITE;
/*!40000 ALTER TABLE `projectcomments55` DISABLE KEYS */;
INSERT INTO `projectcomments55` VALUES (1,55,'<p>New project, project name: Board Mtg Action Items</p>',1326400073,'Gary Gross',117),(3,55,'<p>\r\n	<font face=\"Arial\" size=\"1\">&nbsp;</font>Dan had prepared a list of items to be reviewed during the 1/14/2012 board meeting. You will see the list here in the file, &quot;action_items01-12-2012.pdf&quot;.</p>\r\n<p>\r\n	Here is an update:</p>\r\n<p>\r\n	Members on the list to present at the meeting are Dan, Marie, Brent, John and Nancy. Not all of the items on the list are addressed here so review for complete detail.</p>\r\n<p>\r\n	On &quot;01&quot;, the Mission statement, an Initiative has been created, as well as a project, and the Dater&#39;s have entered the most recent update. You may wish to review before the meeting.</p>\r\n<p>\r\n	On &quot;02&quot;, before the meeting, you can review the most recent updates to the mower shed under the mower shed project.</p>\r\n<p>\r\n	On &quot;03&quot;, so far, no one has suggested a location for the mower shed. Feel free to create a new initiative for locating the mower shed, and make a proposal.</p>\r\n<p>\r\n	On &quot;04&quot;, we have created a new initiative to come up with a mowing plan for 2012. In that initiative we have tried to outline the issues with mowing, and requested the items that a minimum mowing plan should contain &gt; &quot;For 2012, any proposal should include a solution for 1)landscape management, 2) the mowing resource. Cost, quality, reliability, and insurance or ins waiver should also be addressed.&quot; So far no one has created a proposal. Feel free to do so if you have some ideas.</p>\r\n<p>\r\n	On &quot;06&quot;, we have opened a project to review &quot;homeowner businesses&quot;, because we think that if the Walker Co rules are put into effect, we are already in violation in some cases. Feel free to offer any new ideas in the project area.</p>\r\n<p>\r\n	Other items as shown in the list...</p>\r\n',1326468513,'Marie House',118);
/*!40000 ALTER TABLE `projectcomments55` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectcomments56`
--

DROP TABLE IF EXISTS `projectcomments56`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectcomments56` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pjid` smallint(5) unsigned NOT NULL,
  `comment` varchar(6000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedtime` int(10) unsigned DEFAULT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectcomments56`
--

LOCK TABLES `projectcomments56` WRITE;
/*!40000 ALTER TABLE `projectcomments56` DISABLE KEYS */;
INSERT INTO `projectcomments56` VALUES (1,56,'<p>New project, project name: test</p>',1326470037,'Gary Gross',117),(2,56,'<p>\r\n	&nbsp;test</p>\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n',1326470972,'Gary Gross',187),(3,56,'<p>\r\n	test1</p>\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				cell1</td>\r\n			<td>\r\n				cell2</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				&nbsp;</td>\r\n			<td>\r\n				&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n',1326471939,'Gary Gross',187),(4,56,'<p>\r\n	test2</p>\r\n',1326474558,'Gary Gross',187),(5,56,'<p>\r\n	testme</p>\r\n',1326478162,'Gary Gross',187),(6,56,'<p>\r\n	testmeagain</p>\r\n',1326478234,'Gary Gross',187);
/*!40000 ALTER TABLE `projectcomments56` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `pjid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `istatus` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `pjname` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `shortdesc` varchar(160) COLLATE utf8_unicode_ci NOT NULL,
  `abstract` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  `treopened` smallint(5) NOT NULL,
  `whoreopened` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `descname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `datetimeopened` int(10) unsigned DEFAULT NULL,
  `datetimereopened` int(10) unsigned DEFAULT NULL,
  `ctablename` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `filesdir` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth` varchar(1500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`pjid`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (44,'open','BMA Vision Statement','Refine the vision statement','Refine the vision statement','Gary Gross',117,0,'','visionstmt',1323175468,NULL,'projectcomments44','visionstmt','a:17:{i:0;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:1;}i:1;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:1;}i:2;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:1;}i:3;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:1;}i:4;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:1;}i:5;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:1;}i:6;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:1;}i:7;a:3:{s:2:\"id\";s:3:\"177\";s:4:\"name\";s:10:\"Don Folley\";s:5:\"sense\";b:1;}i:8;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:1;}i:9;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:1;}i:10;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:1;}i:12;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:13;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:15;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}i:16;a:3:{s:2:\"id\";s:3:\"184\";s:4:\"name\";s:12:\"Gary W Gross\";s:5:\"sense\";b:1;}}'),(45,'open','Mower Shed Backyard Outfitters','Details of the Backyard Outfitters approach','Details','Marie House',118,0,'','mowershedP1',1323186577,NULL,'projectcomments45','mowershedP1','a:17:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:1;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:1;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:1;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:1;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:1;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:1;}i:6;a:3:{s:2:\"id\";s:3:\"177\";s:4:\"name\";s:10:\"Don Folley\";s:5:\"sense\";b:1;}i:7;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:1;}i:8;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:1;}i:9;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:1;}i:10;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:1;}i:12;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:1;}i:13;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:15;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}i:16;a:3:{s:2:\"id\";s:3:\"184\";s:4:\"name\";s:10:\"Gary Gross\";s:5:\"sense\";b:1;}}'),(46,'open','2012 Budget Discussions','Discussions around how we handle a budget that includes a mower shed, etc.','As the airpark grows and matures the budget (and savings) issues get more involved. Next year the mowers will need a new parking place, and we need to review road condition and repairs as well. Should these be handled as one-time-expenses, or planned to be within a yearly budget?','Gary Gross',184,0,'','2012budget',1323214539,NULL,'projectcomments46','2012budget','a:17:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:1;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:1;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:1;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:1;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:1;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:1;}i:6;a:3:{s:2:\"id\";s:3:\"177\";s:4:\"name\";s:10:\"Don Folley\";s:5:\"sense\";b:1;}i:7;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:1;}i:8;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:1;}i:9;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:1;}i:10;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:1;}i:12;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:1;}i:13;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:15;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}i:16;a:3:{s:2:\"id\";s:3:\"184\";s:4:\"name\";s:10:\"Gary Gross\";s:5:\"sense\";b:1;}}'),(47,'open','Ahrens Projects','All projects related to the Ahrens property at BMA','This project includes all documents and project comments related to Ahrens property, including the hanger and proposed garage','Gary Gross',117,0,'','ahrens',1325423685,NULL,'projectcomments47','ahrens','a:16:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:0;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:0;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:0;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:0;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:0;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:0;}i:6;a:3:{s:2:\"id\";s:3:\"184\";s:4:\"name\";s:10:\"Gary Gross\";s:5:\"sense\";b:0;}i:7;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:0;}i:8;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:1;}i:9;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:0;}i:10;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:0;}i:12;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:0;}i:13;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:15;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:0;}}'),(48,'open','Bertrand\'s Projects','All Bertrand homeowner projects','Everything regarding the Bertrand\'s homeowner building projects and interactions with the architectural committee','Gary Gross',117,0,'','bertrand',1325425910,NULL,'projectcomments48','bertrand','a:16:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:0;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:0;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:0;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:0;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:0;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:0;}i:6;a:3:{s:2:\"id\";s:3:\"184\";s:4:\"name\";s:10:\"Gary Gross\";s:5:\"sense\";b:0;}i:7;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:0;}i:8;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:1;}i:9;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:0;}i:10;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:0;}i:12;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:0;}i:13;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:15;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:0;}}'),(50,'open','BMA Water Line Expansion (Brent) ','Brent Bigham project to expand the water line in BMA','Please contact Brent for more details on this project.\r\nWe have reserved this space for project updates.','Gary Gross',117,0,'','BmaWaterLine',1326211569,NULL,'projectcomments50','BmaWaterLine','a:15:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:0;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:0;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:0;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:0;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:0;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:0;}i:6;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:0;}i:7;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:0;}i:8;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:0;}i:9;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:10;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:0;}i:11;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:0;}i:12;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:13;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}}'),(51,'open','BMA Community Income Sources','BMA income source ideas and discussions','BMA community income could come from any number of sources. These sources are only limited by our creativity.','Gary Gross',117,0,'','incomesrcs',1326219040,NULL,'projectcomments51','incomesrcs','a:15:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:0;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:0;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:0;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:0;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:0;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:0;}i:6;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:0;}i:7;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:0;}i:8;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:0;}i:9;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:10;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:0;}i:11;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:0;}i:12;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:13;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}}'),(52,'open','BMA Maintenance Quality Standards','BMA Maintenance Quality Standards','More formal and higher maintenance quality standards improve BMA lifestyle, and increase resident/property owner property values','Gary Gross',117,0,'','BMAMaintenanceQ',1326219312,NULL,'projectcomments52','BMAMaintenanceQ','a:15:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:0;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:0;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:0;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:0;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:0;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:0;}i:6;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:1;}i:7;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:0;}i:8;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:0;}i:9;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:10;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:0;}i:12;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:13;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}}'),(53,'open','Homeowner Businesses at BMA','Regarding homeowner businesses at BMA, some owners feel that more clarification is needed','BMA homeowner businesses could affect roads, traffic, and security. Some residents feel that more clarification is needed in the covenants.','Gary Gross',117,0,'','BizAtBMA',1326395850,NULL,'projectcomments53','BizAtBMA','a:15:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:1;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:1;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:1;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:1;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:1;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:1;}i:6;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:1;}i:7;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:1;}i:8;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:1;}i:9;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:10;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:1;}i:12;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:13;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}}'),(55,'open','Board Mtg Action Items','Placeholder for action item lists','Placeholder for action item lists','Gary Gross',117,0,'','BrdActionItems',1326400073,NULL,'projectcomments55','BrdActionItems','a:16:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:0;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:0;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:0;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:0;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:0;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:0;}i:6;a:3:{s:2:\"id\";s:3:\"187\";s:4:\"name\";s:10:\"Gary Gross\";s:5:\"sense\";b:0;}i:7;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:1;}i:8;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:0;}i:9;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:0;}i:10;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:1;}i:11;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:0;}i:12;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:0;}i:13;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:1;}i:14;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:1;}i:15;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:1;}}'),(56,'open','test','test','test','Gary Gross',117,0,'','test',1326470037,NULL,'projectcomments56','test','a:16:{i:0;a:3:{s:2:\"id\";s:3:\"153\";s:4:\"name\";s:12:\"Gary Venning\";s:5:\"sense\";b:0;}i:1;a:3:{s:2:\"id\";s:3:\"174\";s:4:\"name\";s:12:\"Quinn Ahrens\";s:5:\"sense\";b:0;}i:2;a:3:{s:2:\"id\";s:3:\"175\";s:4:\"name\";s:12:\"Diana Ahrens\";s:5:\"sense\";b:0;}i:3;a:3:{s:2:\"id\";s:3:\"171\";s:4:\"name\";s:16:\"James Rutherford\";s:5:\"sense\";b:0;}i:4;a:3:{s:2:\"id\";s:3:\"172\";s:4:\"name\";s:14:\"Charles Taylor\";s:5:\"sense\";b:0;}i:5;a:3:{s:2:\"id\";s:3:\"173\";s:4:\"name\";s:13:\"Scott Langton\";s:5:\"sense\";b:0;}i:6;a:3:{s:2:\"id\";s:3:\"187\";s:4:\"name\";s:10:\"Gary Gross\";s:5:\"sense\";b:1;}i:7;a:3:{s:2:\"id\";s:3:\"123\";s:4:\"name\";s:12:\"alisa bigham\";s:5:\"sense\";b:0;}i:8;a:3:{s:2:\"id\";s:3:\"176\";s:4:\"name\";s:12:\"Sarah Hughes\";s:5:\"sense\";b:0;}i:9;a:3:{s:2:\"id\";s:3:\"178\";s:4:\"name\";s:10:\"Tim Hughes\";s:5:\"sense\";b:0;}i:10;a:3:{s:2:\"id\";s:3:\"180\";s:4:\"name\";s:12:\"Brent Bigham\";s:5:\"sense\";b:0;}i:11;a:3:{s:2:\"id\";s:3:\"147\";s:4:\"name\";s:13:\"John Bertrand\";s:5:\"sense\";b:0;}i:12;a:3:{s:2:\"id\";s:3:\"179\";s:4:\"name\";s:14:\"Nancy Bertrand\";s:5:\"sense\";b:0;}i:13;a:3:{s:2:\"id\";s:3:\"118\";s:4:\"name\";s:11:\"Marie House\";s:5:\"sense\";b:0;}i:14;a:3:{s:2:\"id\";s:3:\"124\";s:4:\"name\";s:10:\"Phil Dater\";s:5:\"sense\";b:0;}i:15;a:3:{s:2:\"id\";s:3:\"127\";s:4:\"name\";s:12:\"daniel budde\";s:5:\"sense\";b:0;}}');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposals`
--

DROP TABLE IF EXISTS `proposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposals` (
  `pid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `iid` smallint(5) unsigned NOT NULL,
  `pstatus` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `pname` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `shortdesc` varchar(160) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbynm` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `submittedbyid` smallint(5) NOT NULL,
  `voteid` smallint(5) NOT NULL,
  `duration` smallint(5) NOT NULL,
  `descname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `datetimeopened` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposals`
--

LOCK TABLES `proposals` WRITE;
/*!40000 ALTER TABLE `proposals` DISABLE KEYS */;
INSERT INTO `proposals` VALUES (7,143,'open','Clubhouse and Maintenance Building','An asap solution for housing two zero turn lawnmowers and maintenance equipment','Marie House',118,0,60,'Clubhouse','BMAShedProject.pdf',1321048551),(8,144,'open','Maries Pond Preservation','Inexspensive way to have fish, fishing, hike,biking and invite neighbors for good will to fish fries.','Marie House',118,0,120,'PondP','BMA Pond Project.pdf',1321048551),(12,143,'open','Proposal 2 - Carriage Shed','Received these plans from Phil Dater. Although this proposal is incomplete (missing $ cost info), it looks interesting. If there is enough interest we can pursu','Gary Gross',184,0,60,'CarriageShed','CarriageHouse.pdf',1321836822),(13,143,'open','Justin Cook Proposal','This is the initial Justin Cook perposal but John Bertrand is working with Justin refine his Quote (\"sharpen his pencil\").','Phil Dater',124,0,120,'JustinCookProposal','JustinCookProposal.pdf',1321889577),(14,148,'open','2012 Budget Proposal 1 (from BdMtg)','This proposal includes everything but the mower shed','Gary Gross',184,0,120,'bproposal1','2012 Budget.pdf',1323193431),(15,143,'open','Clubhouse and Maintenance Building Updat','This is original Clubhouse and Maintenance Building updated','Marie House',118,0,90,'bmabldgU1','BMA SHED PROJECT Update1.pdf',1325857568);
/*!40000 ALTER TABLE `proposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tcomments`
--

DROP TABLE IF EXISTS `tcomments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tcomments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(200) DEFAULT NULL,
  `msg_id_fk` int(11) DEFAULT NULL,
  `uid_fk` int(11) DEFAULT NULL,
  `ip` varchar(30) DEFAULT NULL,
  `created` int(11) DEFAULT '1269249260',
  PRIMARY KEY (`com_id`),
  KEY `msg_id_fk` (`msg_id_fk`),
  KEY `uid_fk` (`uid_fk`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tcomments`
--

LOCK TABLES `tcomments` WRITE;
/*!40000 ALTER TABLE `tcomments` DISABLE KEYS */;
INSERT INTO `tcomments` VALUES (1,'My first comment ',1,1,'127.0.0.1',1305209833),(26,'Must watch ',51,2,'127.0.0.1',1305483460),(31,'by Lee Tao',59,2,'127.0.0.1',1305485714);
/*!40000 ALTER TABLE `tcomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmessages`
--

DROP TABLE IF EXISTS `tmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmessages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(200) DEFAULT NULL,
  `uid_fk` int(11) DEFAULT NULL,
  `ip` varchar(30) DEFAULT NULL,
  `created` int(11) DEFAULT '1269249260',
  PRIMARY KEY (`msg_id`),
  KEY `uid_fk` (`uid_fk`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmessages`
--

LOCK TABLES `tmessages` WRITE;
/*!40000 ALTER TABLE `tmessages` DISABLE KEYS */;
INSERT INTO `tmessages` VALUES (1,'Hello',1,'127.0.0.1',1305209778),(2,'My little blog http://9lessons.info',1,'127.0.0.1',1305209846),(51,'Thought of You http://vimeo.com/14803194',1,'127.0.0.1',1305483243),(59,'SEEDLING http://vimeo.com/22912215',1,'127.0.0.1',1305485602),(68,'http://www.youtube.com/watch?v=glzG9lizkSc ',1,'69.40.16.244',1318502329);
/*!40000 ALTER TABLE `tmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tusers`
--

DROP TABLE IF EXISTS `tusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tusers` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tusers`
--

LOCK TABLES `tusers` WRITE;
/*!40000 ALTER TABLE `tusers` DISABLE KEYS */;
INSERT INTO `tusers` VALUES (1,'Srinivas','aaa','srinivas@inbox.com'),(2,'9lessons','test','egglabs@gmail.com');
/*!40000 ALTER TABLE `tusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `rowID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `email` varchar(55) NOT NULL DEFAULT '',
  `pwd` varchar(32) NOT NULL DEFAULT '',
  `add_street` varchar(80) DEFAULT NULL,
  `add_city` varchar(80) DEFAULT NULL,
  `add_state` varchar(80) DEFAULT NULL,
  `add_country` varchar(80) DEFAULT NULL,
  `add_zip` varchar(20) DEFAULT NULL,
  `u_type` tinyint(4) NOT NULL DEFAULT '0',
  `u_priv` tinyint(4) NOT NULL DEFAULT '0',
  `add_apt` varchar(80) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `start_date` int(11) DEFAULT NULL,
  `login_type` varchar(20) DEFAULT NULL,
  `sstartid` bigint(20) DEFAULT NULL,
  `last_access` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `e_notify` tinyint(4) DEFAULT NULL,
  `vid` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`rowID`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (117,'Gary Gross','eightyoctane@yahoo.com','768a7b74b3f9fe2194fbc17efd1876e6','','','','','',2,6,'','eightyoctane','',1291524716,'bluemountain',NULL,NULL,'active',1,0),(118,'Marie House','mariesartwork@yahoo.com','fe25b96834705515777f4e882caf4209','','Trion','ga','USA','30753',2,4,'391 Blue Mountain Lane','mariesartwork','423-605-4483',1291562929,'bluemountain',NULL,NULL,'active',1,1),(124,'Phil Dater','pkdater@mindspring.com','8cad04b6c598dfe96fade4a53217be2f','471  Blue Mountain Lane','Trion','GA','USA','30753',2,4,'','planeview','706 639 9334',1291673431,'bluemountain',NULL,NULL,'active',1,2),(147,'John Bertrand','wingsongaviation@gmail.com','eebeedfdd07b1194d5d2defbfb986195','523 Blue Mountain Lane','Trion','GA','USA','30753',2,3,'','jbertran','615 818 2764 Jcell',1294796941,'bluemountain',NULL,NULL,'active',1,3),(127,'daniel budde','frmfim@comcast.net','1404b3430289074fb19dff1fed6472a5','','kennesaw','ga','USA','30152',2,4,'1216 irma court','facewhack','770-490-3630 (c) (De',1291891929,'bluemountain',NULL,NULL,'active',1,5),(123,'alisa bigham','sambigham@aol.com','04597ebd091c61f4676e04c63cfe27fa','389 blue mountain lane','trion','ga','usa','30753',2,2,'','rivendell','706 638 3041',1291656916,'bluemountain',NULL,NULL,'active',1,6),(128,'KEITH THRIFT','keith.e.thrift.jr@gmail.com','92396ea1230e178474c3e19adceab849','','','','','',1,1,'','KEITH','',1291932647,'bluemountain',NULL,NULL,'active',1,0),(129,'Ronald Rugel','hothopper@hotmail.com','0912df50135d75c8f67a3af1978c38c8','','San Jose','CA','USA','95125',1,1,'1442 Norman Ave.','hothopper','408 267 9642',1292433978,'bluemountain',NULL,NULL,'active',1,0),(149,'Chris Lampe','tiger42r@juno.com','3b75b6739c4365a944f6e497cbbd27b4','','','','','',1,1,'','Tiger42R','',1295381680,'bluemountain',NULL,NULL,'active',1,0),(153,'Gary Venning','gvenning@logic.bm','f62eae2d097821cf6afb741926408391','','Hamilton ','','Bermuda','HM CX',2,1,'P O Box HM 484','gvenning','4412955297',1300104362,'bluemountain',NULL,NULL,'active',1,7),(154,'Philip Pecoulas','ppecoulas@yahoo.com','12dda62beace2b053ee392e8e8f94f24','','','','','',2,5,'','ppecoul','813 361 6955',1301933447,'bluemountain',NULL,NULL,'active',0,8),(155,'Charles Aaron','cubdriverj3@windstream.net','31688572580a6b4cc60b06855ceb34e2','','Chatsworth','Georgia','USA','30705',1,1,'42 Loughridge Rd.','charlieaileron','706-280-9550',1303600055,'bluemountain',NULL,NULL,'active',1,0),(174,'Quinn Ahrens','qahrens@yahoo.com','c9beb97a65a013e30adb9f260e65d76e','','','','','',2,1,'','qahrens','',1315815499,'bluemountain',NULL,NULL,'active',1,9),(168,'Gary Gross','eightyoctane@yahoo.com','26744aa9d6c04c246957fb97d987546c','','','','','',3,7,'','contractor','',1312539608,'bluemountain',NULL,NULL,'active',0,0),(175,'Diana Ahrens','diana_ahrens@yahoo.com','01ed103a96a0e158e9b30ffa0ac0ed65','317 Blue Mountain Lane','Trion','GA','USA','30753',2,1,'','dahrens','775-342-7175',1315815796,'bluemountain',NULL,NULL,'active',1,9),(171,'James Rutherford','canterpiroutte@comcast.net','0458856d95f040baf6f3618b7fa37555','13672 Cygnus Drive','Orlando','FL','USA','32828',2,1,'','rutherford','352-239-1334',1315768271,'bluemountain',NULL,NULL,'active',1,10),(172,'Charles Taylor','ctaylor377@yahoo.com','2bd3c5187b8ea6a4dfd8b94b7226e9c9','PO Box 493504','Leesburg','FL','','',2,1,'','taylor','352-267-0207',1315768501,'bluemountain',NULL,NULL,'active',1,13),(173,'Scott Langton','scottlangtondvm@hotmail.com','61fadf19a0b0afe89450f858323436ac','3520-3 Avalon Park Blvd East','Orlando','FL','USA','32828',2,1,'','langton','321-303-7421',1315768735,'bluemountain',NULL,NULL,'active',1,11),(176,'Sarah Hughes','sagnellae@aim.com','d4b23fc47ea7d518deaf6fff6f6904f6','276 Dogwood Drive','Canton','GA','USA','30114',2,2,'','sagnellae','770-345-1333',1315816040,'bluemountain',NULL,NULL,'active',0,12),(177,'Don Folley','cndf@cox.net','b6290f2ee8f09ceeeab7d4709645f5ca','','','','','',1,1,'','dfolley','',1316021739,'bluemountain',NULL,NULL,'inactive',1,0),(178,'Tim Hughes','anyelectric1@comcast.net','d4b23fc47ea7d518deaf6fff6f6904f6','','','','','',2,2,'','thughes','',1316353045,'bluemountain',NULL,NULL,'active',1,12),(179,'Nancy Bertrand','nancyparksbertrand@gmail.com','98b7772b1fd8c1427e5c8db8f3ebb2c9','','','','','',2,3,'','nbertrand','706-638-2569 (hm)',1316612052,'bluemountain',NULL,NULL,'active',1,4),(180,'Brent Bigham','brentbigham1@yahoo.com','88a3cf055778b6aa9901ec2ea3a2319d','','','','','',2,2,'','brentbigham1','',1316612413,'bluemountain',NULL,NULL,'active',1,6),(187,'Gary Gross','eightyoctane@yahoo.com','768a7b74b3f9fe2194fbc17efd1876e6','','','','','',2,1,'','ggross','',1326200583,'bluemountain',NULL,NULL,'active',0,1),(186,'Ronald A Tyler','alantyler@gmail.com','81131f25823c5a7b16e031d15d46a046','','Adairsville','Georgia','United States','30103',1,1,'Po Box 803','alantyler','706 602 2122',1322370556,'bluemountain',NULL,NULL,'active',1,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vote`
--

DROP TABLE IF EXISTS `vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vote` (
  `voteid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `vstatus` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `vtablename` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `vdesc` varchar(160) COLLATE utf8_unicode_ci NOT NULL,
  `iorpid` smallint(5) unsigned NOT NULL,
  `votetype` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `datetimeopened` int(10) unsigned DEFAULT NULL,
  `duration` smallint(5) unsigned DEFAULT NULL,
  `votesyes` tinyint(4) unsigned DEFAULT NULL,
  `votesno` tinyint(4) unsigned DEFAULT NULL,
  `votesnone` tinyint(4) unsigned DEFAULT NULL,
  `comments` varchar(600) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vresult` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datetimeclosed` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`voteid`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vote`
--

LOCK TABLES `vote` WRITE;
/*!40000 ALTER TABLE `vote` DISABLE KEYS */;
INSERT INTO `vote` VALUES (132,'closed','initiativemowershedresidentsvote132','',0,'initiative',1321048551,60,0,0,11,'Marie House|yes|See community projects page for updates|Phil Dater|none|none|John Bertrand|none|none|Nancy Bertrand|none|none|daniel budde|none|none|alisa bigham|none|none|Gary Venning|none|none|Philip Pecoulas|none|none|Quinn Ahrens|none|none|James Rutherford|none|none|Scott Langton|none|none|Sarah Hughes|none|none|','uncertainq',NULL),(133,'open','initiativePondimprovementresidentsvote133','',144,'initiative',1321050911,120,NULL,NULL,NULL,NULL,NULL,NULL),(134,'open','initiativeMowPlan2012residentsvote134','',145,'initiative',1321747525,60,NULL,NULL,NULL,NULL,NULL,NULL),(136,'open','initiativeMissionboardvote136','',147,'initiative',1322619550,35,NULL,NULL,NULL,NULL,NULL,NULL),(137,'open','initiative2012budgetresidentsvote137','',148,'initiative',1323193320,120,NULL,NULL,NULL,NULL,NULL,NULL),(149,'open','initiativemowershedresidentsvote149','',143,'initiative',0,60,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `vote` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-01-14 13:19:21
