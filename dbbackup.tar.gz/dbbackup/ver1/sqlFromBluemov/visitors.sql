-- MySQL dump 10.13  Distrib 5.1.58, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: bluemov2_visitors
-- ------------------------------------------------------
-- Server version	5.1.58-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `msg_id_fk` int(11) DEFAULT NULL,
  `u_id` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`com_id`),
  KEY `msg_id_fk` (`msg_id_fk`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (88,NULL,'test3',197,117),(101,NULL,'	comment on \"One\"		',206,156),(90,NULL,'	test2	',198,117),(91,NULL,'test3',198,117),(92,NULL,'test5		',199,117),(93,NULL,'	gary	',200,117),(94,NULL,'	test9\n		',201,117),(95,NULL,'	hello		',201,117),(96,NULL,'	new comment		',201,117),(97,NULL,' http://www.youtube.com/watch?v=5-EezcpFzVI',201,117),(98,NULL,'	hhhhhhhh	',203,117),(99,NULL,'nnnnnnnn',203,117),(102,NULL,'dsflkjsdflkjsdfkjsd\n		',213,117),(103,NULL,'	So true gary!\n	',215,117);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `message` varchar(200) DEFAULT NULL,
  `u_id` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=220 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (205,NULL,' http://www.youtube.com/watch?v=5-EezcpFzVI ',156),(199,NULL,'test4',117),(200,NULL,'marie',117),(201,NULL,'http://www.youtube.com/watch?v=5-EezcpFzVI\n\n',117),(202,NULL,' http://www.youtube.com/watch?v=5-EezcpFzVI',117),(204,NULL,'ggggg',117),(206,NULL,'One  http://www.youtube.com/watch?v=5-EezcpFzVI ',156),(207,NULL,'We have a new login user type now, called \"Contractor\"',117),(208,NULL,' http://www.youtube.com/watch?v=5-EezcpFzVI',117),(209,NULL,'testing',117),(210,NULL,'dfdsfdsf',117),(211,NULL,'fddssdf',117),(212,NULL,'dsfsdfsddsfsdf',117),(213,NULL,'sdfjsdflkjsdfkljsdf',117),(214,NULL,'from dennis',117),(215,NULL,'the real facebook is an imposter\n',117),(216,NULL,'http://www.youtube.com/watch?v=8zg2A9M6QqY',117),(217,NULL,'http://www.youtube.com/watch?v=8zg2A9M6QqY\n',117),(218,NULL,'http://www.mariesartwork.com\n',117),(219,NULL,'http://www.mariesartwork.com\n',117);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `rowID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `email` varchar(55) NOT NULL DEFAULT '',
  `pwd` varchar(32) NOT NULL DEFAULT '',
  `add_street` varchar(80) DEFAULT NULL,
  `add_city` varchar(80) DEFAULT NULL,
  `add_state` varchar(80) DEFAULT NULL,
  `add_country` varchar(80) DEFAULT NULL,
  `add_zip` varchar(20) DEFAULT NULL,
  `u_type` tinyint(4) NOT NULL DEFAULT '0',
  `u_priv` tinyint(4) NOT NULL DEFAULT '0',
  `add_apt` varchar(80) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `start_date` int(11) DEFAULT NULL,
  `login_type` varchar(20) DEFAULT NULL,
  `sstartid` bigint(20) DEFAULT NULL,
  `last_access` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`rowID`)
) ENGINE=MyISAM AUTO_INCREMENT=169 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (117,'Gary Gross','eightyoctane@yahoo.com','768a7b74b3f9fe2194fbc17efd1876e6','','','','','',2,6,'','eightyoctane','',1291524716,'bluemountain',NULL,NULL,'active'),(118,'Marie House','mariesartwork@yahoo.com','b1a4041c3de5df34d3bd3d469928ccaf','','Trion','ga','USA','30753',2,4,'391 Blue Mountain Lane','mariesartwork','423-605-4483',1291562929,'bluemountain',NULL,NULL,'active'),(124,'Phil Dater','pkdater@mindspring.com','8cad04b6c598dfe96fade4a53217be2f','471  Blue Mountain Lane','Trion','GA','USA','30753',2,4,'','planeview','706 639 9334',1291673431,'bluemountain',NULL,NULL,'active'),(147,'John Bertrand','wingsongaviation@gmail.com','eebeedfdd07b1194d5d2defbfb986195','','Murfreesboro','TN','USA','37127',2,1,'101 Woodbiury St.','jbertran','615 818 2764',1294796941,'bluemountain',NULL,NULL,'active'),(127,'daniel budde','frmfim@comcast.net','1404b3430289074fb19dff1fed6472a5','','kennesaw','ga','us','30152',2,4,'1216 irma court','facewhack','',1291891929,'bluemountain',NULL,NULL,'active'),(123,'alisa bigham','sambigham@aol.com','2ff2d114f3fffaa76bd8d1babc7e0c09','389 blue mountain lane','trion','ga','usa','30753',2,2,'','rivendell','706 638 3041',1291656916,'bluemountain',NULL,NULL,'active'),(128,'KEITH THRIFT','keith.e.thrift.jr@gmail.com','92396ea1230e178474c3e19adceab849','','','','','',1,1,'','KEITH','',1291932647,'bluemountain',NULL,NULL,'active'),(129,'Ronald Rugel','hothopper@hotmail.com','0912df50135d75c8f67a3af1978c38c8','','San Jose','CA','USA','95125',1,1,'1442 Norman Ave.','hothopper','408 267 9642',1292433978,'bluemountain',NULL,NULL,'active'),(149,'Chris Lampe','tiger42r@juno.com','3b75b6739c4365a944f6e497cbbd27b4','','','','','',1,1,'','Tiger42R','',1295381680,'bluemountain',NULL,NULL,'active'),(153,'Gary Venning','gvenning@logic.bm','f62eae2d097821cf6afb741926408391','','Hamilton ','','Bermuda','HM CX',2,1,'P O Box HM 484','gvenning','4412955297',1300104362,'bluemountain',NULL,NULL,'active'),(154,'Philip Pecoulas','ppecoulas@yahoo.com','ba4e9aba64471e263be28dd97072cbc9','','','','','',2,5,'','ppecoul','813 361 6955',1301933447,'bluemountain',NULL,NULL,'active'),(155,'Charles Aaron','cubdriverj3@windstream.net','31688572580a6b4cc60b06855ceb34e2','','Chatsworth','Georgia','USA','30705',1,1,'42 Loughridge Rd.','charlieaileron','706-280-9550',1303600055,'bluemountain',NULL,NULL,'active'),(157,'Gary Gross','eightyoctane@yahoo.com','a19ea622182c63ddc19bb22cde982b82','','','','','',3,8,'','develop','',1311959636,'bluemountain',NULL,NULL,'active'),(168,'Gary Gross','eightyoctane@yahoo.com','26744aa9d6c04c246957fb97d987546c','','','','','',3,7,'','contractor','',1312539608,'bluemountain',NULL,NULL,'active'),(162,'Haley Keller','haley@paulcummings.com','20ffe33b96ff72c5a738fc452bd2fe12','','','','','',2,4,'','webexample','',1311970236,'bluemountain',NULL,NULL,'active');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-08-31 17:18:01
