-- MySQL dump 10.13  Distrib 5.1.58, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: bluemov2_dfg
-- ------------------------------------------------------
-- Server version	5.1.58-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bluemov2_content`
--

DROP TABLE IF EXISTS `bluemov2_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bluemov2_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned DEFAULT NULL,
  `type` varchar(32) NOT NULL,
  `title` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_bluemov2__pid_id` (`pid`),
  KEY `FK_bluemov2__uid_uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bluemov2_content`
--

LOCK TABLES `bluemov2_content` WRITE;
/*!40000 ALTER TABLE `bluemov2_content` DISABLE KEYS */;
INSERT INTO `bluemov2_content` VALUES (1,1,NULL,'gallery','Main'),(2,1,1,'album','TopLevelHomePage'),(3,1,2,'image','DSC_0013w01'),(4,1,2,'image','DSC_0013w02'),(5,1,2,'image','DSC_0013w03'),(6,1,2,'image','DSC_0013w04'),(7,1,2,'image','DSC_0013w05'),(8,1,2,'image','DSC_0013w06'),(9,1,2,'image','DSC_0013w07'),(10,1,2,'image','DSC_0013w08'),(15,1,2,'image','DSC_0013w13'),(16,1,2,'image','C:\\fakepath\\IMG_0619'),(24,1,2,'image','Christmas Deer 2010'),(26,1,NULL,'gallery','Events'),(27,1,NULL,'gallery','Events 2010'),(28,1,27,'album','EventAlbum'),(29,1,26,'album','EventAlbum'),(30,1,29,'image','Twin Low Pass'),(31,1,29,'image','Hughes 500'),(32,1,29,'image','Landscape1'),(33,1,29,'image','Group1'),(34,1,29,'image','Group2'),(35,1,29,'image','All in a Row'),(36,1,28,'image','Day After'),(37,1,NULL,'gallery','WaterLineExpansion'),(38,1,37,'album','Layout 1'),(39,1,38,'image','Diag1'),(40,1,38,'image','Diag2'),(41,1,2,'image','Christmas Eve Midnight 2010'),(43,1,2,'image','Christmas Day 2010'),(47,1,44,'image','No way out... :-)'),(49,1,44,'image','Happy Dog in the Snow'),(50,1,44,'image','Welcome Home Neighbor!'),(51,1,44,'image','Where\'s the airstrip?'),(52,1,44,'image','Snow Day!'),(53,1,NULL,'gallery','ResidentsPhotos'),(54,1,53,'album','January Snow 2011'),(55,1,54,'image','No way out!'),(56,1,54,'image','Happy Snow Dog'),(57,1,54,'image','Welcome Home Neighbors! (1)'),(58,1,54,'image','Welcome Home Neighbors! (2)'),(59,1,54,'image','Where\'s the airstrip?'),(60,1,53,'album','BMA Airport Work Day 3/2011'),(61,1,60,'image','Windsock Maintenance Crew'),(62,1,53,'album','Spring time at  BMA'),(63,1,62,'image','Spring time at BMA'),(64,1,62,'image','Wildflowers BMA'),(65,1,62,'image','C:\\fakepath\\DSC_0055'),(66,1,62,'image','C:\\fakepath\\DSC_0061'),(67,1,62,'image','C:\\fakepath\\DSC_0064'),(68,1,62,'image','C:\\fakepath\\DSC_0062'),(74,1,2,'image','Trike Up UP and AWAY!'),(75,1,53,'album','Trike Flight');
/*!40000 ALTER TABLE `bluemov2_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bluemov2_contentprop`
--

DROP TABLE IF EXISTS `bluemov2_contentprop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bluemov2_contentprop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  KEY `FK_bluemov2__cid_id` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=222 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bluemov2_contentprop`
--

LOCK TABLES `bluemov2_contentprop` WRITE;
/*!40000 ALTER TABLE `bluemov2_contentprop` DISABLE KEYS */;
INSERT INTO `bluemov2_contentprop` VALUES (1,1,'theme','standard'),(2,1,'skin','standard.png'),(3,2,'album_type','custom'),(4,3,'thumbnail_file','DSC_0013w01.JPG'),(5,3,'image_file','DSC_0013w01.JPG'),(6,3,'timestamp','1288222264'),(7,4,'thumbnail_file','DSC_0013w02.JPG'),(8,4,'image_file','DSC_0013w02.JPG'),(9,4,'timestamp','1288222270'),(10,5,'thumbnail_file','DSC_0013w03.JPG'),(11,5,'image_file','DSC_0013w03.JPG'),(12,5,'timestamp','1288222276'),(13,6,'thumbnail_file','DSC_0013w04.JPG'),(14,6,'image_file','DSC_0013w04.JPG'),(15,6,'timestamp','1288222282'),(16,7,'thumbnail_file','DSC_0013w05.JPG'),(17,7,'image_file','DSC_0013w05.JPG'),(18,7,'timestamp','1288222288'),(19,8,'thumbnail_file','DSC_0013w06.JPG'),(20,8,'image_file','DSC_0013w06.JPG'),(21,8,'timestamp','1288222294'),(22,9,'thumbnail_file','DSC_0013w07.JPG'),(23,9,'image_file','DSC_0013w07.JPG'),(24,9,'timestamp','1288222301'),(25,10,'thumbnail_file','DSC_0013w08.JPG'),(26,10,'image_file','DSC_0013w08.JPG'),(27,10,'timestamp','1288222306'),(40,15,'thumbnail_file','DSC_0013w13.jpg'),(41,15,'image_file','DSC_0013w13.jpg'),(42,15,'timestamp','1288222352'),(43,2,'config_image_width','700'),(44,2,'config_image_height','400'),(45,2,'config_thumbnail_width','75'),(46,2,'config_thumbnail_height','50'),(47,16,'thumbnail_file','IMG_0619.JPG'),(48,16,'image_file','IMG_0619.JPG'),(49,16,'timestamp','1288265068'),(72,24,'image_file','DSC_00041.JPG'),(71,24,'thumbnail_file','DSC_00041.JPG'),(73,24,'timestamp','1290535549'),(77,26,'theme','standard'),(78,26,'skin','standard.png'),(79,26,'config_theme_music',''),(80,26,'config_theme_slideshow_pauseAtStart','false'),(81,26,'config_theme_slideshow_interval','5'),(82,26,'config_theme_use_skin_config','true'),(83,27,'theme','standard'),(84,27,'skin','standard.png'),(85,28,'album_type','custom'),(86,29,'album_type','custom'),(87,29,'config_image_width','700'),(88,29,'config_image_height','400'),(89,29,'config_thumbnail_width','75'),(90,29,'config_thumbnail_height','50'),(91,27,'config_theme_music',''),(92,27,'config_theme_slideshow_pauseAtStart','false'),(93,27,'config_theme_slideshow_interval','5'),(94,27,'config_theme_use_skin_config','true'),(95,28,'config_image_width','700'),(96,28,'config_image_height','400'),(97,28,'config_thumbnail_width','75'),(98,28,'config_thumbnail_height','50'),(99,30,'thumbnail_file','TwinLowPass.JPG'),(100,30,'image_file','TwinLowPass.JPG'),(101,30,'timestamp','1291855118'),(102,31,'thumbnail_file','IMG_0202.JPG'),(103,31,'image_file','IMG_0202.JPG'),(104,31,'timestamp','1291855457'),(105,32,'thumbnail_file','IMG_0203.JPG'),(106,32,'image_file','IMG_0203.JPG'),(107,32,'timestamp','1291855471'),(108,33,'thumbnail_file','IMG_0193.JPG'),(109,33,'image_file','IMG_0193.JPG'),(110,33,'timestamp','1291855483'),(111,34,'thumbnail_file','IMG_0195.JPG'),(112,34,'image_file','IMG_0195.JPG'),(113,34,'timestamp','1291855495'),(114,35,'thumbnail_file','IMG_0194.JPG'),(115,35,'image_file','IMG_0194.JPG'),(116,35,'timestamp','1291855505'),(117,36,'thumbnail_file','DSC_0075.JPG'),(118,36,'image_file','DSC_0075.JPG'),(119,36,'timestamp','1291855662'),(120,37,'theme','standard'),(121,37,'skin','standard.png'),(122,38,'album_type','custom'),(123,39,'thumbnail_file','Scan_Pic0005.jpg'),(124,39,'image_file','Scan_Pic0005.jpg'),(125,39,'timestamp','1291930196'),(126,40,'thumbnail_file','Scan_Pic0006.jpg'),(127,40,'image_file','Scan_Pic0006.jpg'),(128,40,'timestamp','1291930207'),(129,41,'thumbnail_file','DSC_0084e.JPG'),(130,41,'image_file','DSC_0084e.JPG'),(131,41,'timestamp','1293314874'),(136,43,'image_file','DSC_0112e.JPG'),(135,43,'thumbnail_file','DSC_0112e.JPG'),(137,43,'timestamp','1293385158'),(147,47,'timestamp','1294691047'),(146,47,'image_file','DSC_0406e.JPG'),(145,47,'thumbnail_file','DSC_0406e.JPG'),(150,49,'thumbnail_file','DSC_0417a1.JPG'),(151,49,'image_file','DSC_0417a1.JPG'),(152,49,'timestamp','1294778136'),(153,50,'thumbnail_file','DSC_0419a.JPG'),(154,50,'image_file','DSC_0419a.JPG'),(155,50,'timestamp','1294778251'),(156,51,'thumbnail_file','DSC_0421a.JPG'),(157,51,'image_file','DSC_0421a.JPG'),(158,51,'timestamp','1294778355'),(159,52,'thumbnail_file','DSC_0428a.JPG'),(160,52,'image_file','DSC_0428a.JPG'),(161,52,'timestamp','1294778571'),(162,53,'theme','standard'),(163,53,'skin','standard.png'),(164,54,'album_type','custom'),(165,55,'thumbnail_file','DSC_0406e1.JPG'),(166,55,'image_file','DSC_0406e1.JPG'),(167,55,'timestamp','1295023325'),(168,56,'thumbnail_file','DSC_0417a2.JPG'),(169,56,'image_file','DSC_0417a2.JPG'),(170,56,'timestamp','1295045874'),(171,57,'thumbnail_file','DSC_0419a1.JPG'),(172,57,'image_file','DSC_0419a1.JPG'),(173,57,'timestamp','1295045995'),(174,58,'thumbnail_file','DSC_0420a.JPG'),(175,58,'image_file','DSC_0420a.JPG'),(176,58,'timestamp','1295046078'),(177,59,'thumbnail_file','DSC_0421a1.JPG'),(178,59,'image_file','DSC_0421a1.JPG'),(179,59,'timestamp','1295046177'),(180,60,'album_type','custom'),(181,61,'thumbnail_file','DSC_0027.JPG'),(182,61,'image_file','DSC_0027.JPG'),(183,61,'timestamp','1299967087'),(184,62,'album_type','custom'),(185,63,'thumbnail_file','DSC_0053.JPG'),(186,63,'image_file','DSC_0053.JPG'),(187,63,'timestamp','1301940834'),(188,64,'thumbnail_file','DSC_0083.JPG'),(189,64,'image_file','DSC_0083.JPG'),(190,64,'timestamp','1301941767'),(191,65,'thumbnail_file','DSC_0055.JPG'),(192,65,'image_file','DSC_0055.JPG'),(193,65,'timestamp','1301941830'),(194,66,'thumbnail_file','DSC_0061.JPG'),(195,66,'image_file','DSC_0061.JPG'),(196,66,'timestamp','1301941892'),(197,67,'thumbnail_file','DSC_0064.JPG'),(198,67,'image_file','DSC_0064.JPG'),(199,67,'timestamp','1301941954'),(200,68,'thumbnail_file','DSC_0062.JPG'),(201,68,'image_file','DSC_0062.JPG'),(202,68,'timestamp','1301942017'),(218,74,'thumbnail_file','DSC_0136.JPG'),(219,74,'image_file','DSC_0136.JPG'),(220,74,'timestamp','1303233427'),(221,75,'album_type','flickr');
/*!40000 ALTER TABLE `bluemov2_contentprop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bluemov2_systemprop`
--

DROP TABLE IF EXISTS `bluemov2_systemprop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bluemov2_systemprop` (
  `name` varchar(100) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bluemov2_systemprop`
--

LOCK TABLES `bluemov2_systemprop` WRITE;
/*!40000 ALTER TABLE `bluemov2_systemprop` DISABLE KEYS */;
INSERT INTO `bluemov2_systemprop` VALUES ('flickr_api_key','dc123ae6ab78886c452b7ad44ec171c6');
/*!40000 ALTER TABLE `bluemov2_systemprop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bluemov2_users`
--

DROP TABLE IF EXISTS `bluemov2_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bluemov2_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `password` varchar(64) NOT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `created` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bluemov2_users`
--

LOCK TABLES `bluemov2_users` WRITE;
/*!40000 ALTER TABLE `bluemov2_users` DISABLE KEYS */;
INSERT INTO `bluemov2_users` VALUES (1,'admin','e384d731df64ccd6f3a7e8ed3c802db92682fb72',NULL,1288220247);
/*!40000 ALTER TABLE `bluemov2_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-08-31 17:18:01
