-- MySQL dump 10.13  Distrib 5.1.47, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: bluemov2_calendar
-- ------------------------------------------------------
-- Server version	5.1.47-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ltw_categoryv4`
--

DROP TABLE IF EXISTS `ltw_categoryv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_categoryv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `fgcolor` char(8) NOT NULL DEFAULT '#000000',
  `bgcolor` char(8) NOT NULL DEFAULT '#ffffff',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_categoryv4`
--

LOCK TABLES `ltw_categoryv4` WRITE;
/*!40000 ALTER TABLE `ltw_categoryv4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ltw_categoryv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltw_eventsv4`
--

DROP TABLE IF EXISTS `ltw_eventsv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_eventsv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `event_date` date NOT NULL DEFAULT '0000-00-00',
  `start_time` time NOT NULL DEFAULT '00:00:00',
  `end_time` time NOT NULL DEFAULT '00:00:00',
  `description` text NOT NULL,
  `recurring` tinyint(4) NOT NULL DEFAULT '0',
  `recur_dayofweek` tinyint(4) DEFAULT NULL,
  `day_event` tinyint(4) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL DEFAULT '1',
  `event_end` date NOT NULL DEFAULT '0000-00-00',
  `location` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_date` (`event_date`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_eventsv4`
--

LOCK TABLES `ltw_eventsv4` WRITE;
/*!40000 ALTER TABLE `ltw_eventsv4` DISABLE KEYS */;
INSERT INTO `ltw_eventsv4` VALUES (1,'Bigham Pancake Dinner','2010-12-07','18:00:00','20:00:00','Original arrangements made via email',0,NULL,0,0,'2010-12-07',''),(3,'Katie&Phil EggNog&Potluck','2010-12-11','17:00:00','20:00:00','',0,NULL,0,0,'2010-12-11','The Daters');
/*!40000 ALTER TABLE `ltw_eventsv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltw_logv4`
--

DROP TABLE IF EXISTS `ltw_logv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_logv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `occured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` varchar(20) DEFAULT NULL,
  `info` text,
  PRIMARY KEY (`id`),
  KEY `idx_occured` (`occured`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_logv4`
--

LOCK TABLES `ltw_logv4` WRITE;
/*!40000 ALTER TABLE `ltw_logv4` DISABLE KEYS */;
INSERT INTO `ltw_logv4` VALUES (1,1,'2010-12-07 11:20:20','','<b>Login</b>: User admin login ok'),(2,3,'2010-12-07 11:23:06','admin','<B>Event: Added</b><br>Name: Pancake Dinner @ the Bigham\\\\\\\'s<br>Location: <br>Event_date: 2010-12-07<br>Start_time: 18:00:00<br>Event_end: 2010-12-07<br>End_time: 20:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>Original arrangements made via email'),(3,3,'2010-12-07 11:24:10','admin','<b>Event: Updated</b> Pancake Dinner @ the Bigham\\(1)<br>Name: Pancake Dinner @ the Bigham\\->Bigham Pancake Dinner<br>'),(4,3,'2010-12-07 11:25:50','admin','<B>Event: Added</b><br>Name: testevent<br>Location: Community Area<br>Event_date: 2010-12-07<br>Start_time: 10:00:00<br>Event_end: 2010-12-07<br>End_time: 10:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>test hyperlink:\r\nhttp://www.bluemountainairpark.com '),(5,3,'2010-12-07 11:28:14','admin','<b>Event:  Deleted</b>(2)<br>Name: testevent<br>Location: Community Area<br>Event_date: 2010-12-07<br>Event_end: 2010-12-07<br>Start_time: 10:00:00<br>End_time: 10:00:00<br>Day_event: 0<br>Recurring: 0<br>Category: <br>Description: test hyperlink:\r\nhttp://www.bluemountainairpark.com '),(6,1,'2010-12-07 11:50:51','admin','<b>User: Add katie</b><br>Password set<br>Last_Pw_Change: 2010-12-07 04:0:51<br>Email: pkdater@mindspring.com<br>Locked Status: Off<br>Change Pw Status: Off<br>Read Priv: On<br>Edit Priv: On<br>Email Priv: On<br>Logs Priv: Off<br>Admin Priv: Off<br>'),(7,1,'2010-12-07 12:09:40','','<b>Login</b>: User admin logged out'),(8,1,'2010-12-07 12:10:29','','<b>Login</b>: User katie login ok'),(9,1,'2010-12-07 12:10:44','','<b>Login</b>: User katie logged out'),(10,1,'2010-12-07 14:05:42','','<b>Login</b>: User katie login ok'),(11,1,'2010-12-07 14:06:09','','<b>Login</b>: User katie logged out'),(12,1,'2010-12-08 10:49:17','','<b>Login</b>: User katie login ok'),(13,1,'2010-12-08 10:56:33','','<b>Login</b>: User katie logged out'),(14,1,'2010-12-08 10:58:50','','<b>Login</b>: User admin login ok'),(15,1,'2010-12-08 11:01:14','admin','<b>User: Add anybody</b><br>Password set<br>Last_Pw_Change: 2010-12-08 04:0:14<br>Locked Status: Off<br>Change Pw Status: Off<br>Read Priv: On<br>Edit Priv: On<br>Email Priv: Off<br>Logs Priv: Off<br>Admin Priv: Off<br>'),(16,1,'2010-12-08 11:01:37','','<b>Login</b>: User admin logged out'),(17,1,'2010-12-08 11:47:20','','<b>Login</b>: User anybody login ok'),(18,1,'2010-12-08 14:38:31','','<b>Login</b>: User anybody login ok'),(19,1,'2010-12-11 12:48:03','','<b>Login</b>: User admin login ok'),(20,3,'2010-12-11 12:49:55','admin','<B>Event: Added</b><br>Name: Katie&Phil EggNog&Potluck<br>Location: The Daters<br>Event_date: 2010-12-11<br>Start_time: 17:00:00<br>Event_end: 2010-12-11<br>End_time: 20:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>'),(21,1,'2010-12-11 12:50:32','','<b>Login</b>: User admin logged out'),(22,1,'2010-12-11 12:50:57','','<b>Login</b>: User anybody login ok'),(23,1,'2010-12-11 12:52:12','','<b>Login</b>: User anybody logged out');
/*!40000 ALTER TABLE `ltw_logv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltw_usersv4`
--

DROP TABLE IF EXISTS `ltw_usersv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_usersv4` (
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '0',
  `privledges` int(11) NOT NULL DEFAULT '1',
  `bad_logins` int(11) NOT NULL DEFAULT '0',
  `bad_logins_start` char(15) DEFAULT NULL,
  `last_pw_change` datetime DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_usersv4`
--

LOCK TABLES `ltw_usersv4` WRITE;
/*!40000 ALTER TABLE `ltw_usersv4` DISABLE KEYS */;
INSERT INTO `ltw_usersv4` VALUES ('admin','RbL6GIjq.wgQI','eightyoctane@yahoo.com',0,128,0,'','2010-12-07 04:00:19'),('katie','Rb39LeU3ORvFA','pkdater@mindspring.com',0,7,0,'','2010-12-07 04:00:51'),('anybody','RbYsSgLmLMC12','',0,3,0,'','2010-12-08 04:00:14');
/*!40000 ALTER TABLE `ltw_usersv4` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-12-27 15:12:26
