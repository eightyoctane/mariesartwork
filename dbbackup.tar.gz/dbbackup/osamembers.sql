-- MySQL dump 10.13  Distrib 5.1.56, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: bmasite_osamembers
-- ------------------------------------------------------
-- Server version	5.1.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `msg_id_fk` int(11) DEFAULT NULL,
  PRIMARY KEY (`com_id`),
  KEY `msg_id_fk` (`msg_id_fk`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (41,NULL,'hello\n		',98),(42,NULL,'http://www.bluemountainairpark.com/login/facebook_WallScript_2.0/airparkcareWall.php#',98),(43,NULL,'	test1	',100),(44,NULL,'http://www.youtube.com/watch?v=XnHuIET4P2s',106),(45,NULL,'there\n		',108),(46,NULL,'there		',109),(47,NULL,'going		',110),(48,NULL,'ttttt		',112),(49,NULL,'test2\n		',113);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `message` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (98,NULL,'hello'),(99,NULL,'http://www.bluemountainairpark.com/login/facebook_WallScript_2.0/airparkcareWall.php#'),(100,NULL,'test'),(101,NULL,'http://www.gadling.com/2011/03/03/downhill-bike-race-in-chile-is-insanity-at-its-finest/'),(102,NULL,'http://www.gadling.com/2011/03/03/downhill-bike-race-in-chile-is-insanity-at-its-finest/ \n'),(103,NULL,'http://www.gadling.com/2011/03/03/downhill-bike-race-in-chile-is-insanity-at-its-finest/ '),(104,NULL,'http://vimeo.com/20404150 '),(105,NULL,'http://www.eaa.org/news/2010/2010-08-17_BRS-WingSeparate.asp '),(106,NULL,'http://www.youtube.com/watch?v=XnHuIET4P2s'),(107,NULL,'http://www.eaa.org/news/2010/2010-08-17_BRS-WingSeparate.asp '),(108,NULL,'hello\n'),(109,NULL,'hello\n'),(110,NULL,'what\'s'),(111,NULL,'gfdgdfdfg'),(112,NULL,'wht'),(113,NULL,'test1\n'),(114,NULL,'test'),(115,NULL,'tst'),(116,NULL,'test92'),(117,NULL,'test'),(118,NULL,'rrrrr'),(119,NULL,'ggggg'),(120,NULL,'ggggg'),(121,NULL,'hello'),(122,NULL,'hello'),(123,NULL,'myyyyy');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `rowID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `email` varchar(55) NOT NULL DEFAULT '',
  `pwd` varchar(32) NOT NULL DEFAULT '',
  `add_street` varchar(80) DEFAULT NULL,
  `add_city` varchar(80) DEFAULT NULL,
  `add_state` varchar(80) DEFAULT NULL,
  `add_country` varchar(80) DEFAULT NULL,
  `add_zip` varchar(20) DEFAULT NULL,
  `u_type` tinyint(4) NOT NULL DEFAULT '0',
  `u_priv` tinyint(4) NOT NULL DEFAULT '0',
  `add_apt` varchar(80) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `start_date` int(11) DEFAULT NULL,
  `login_type` varchar(20) DEFAULT NULL,
  `sstartid` bigint(20) DEFAULT NULL,
  `last_access` int(11) DEFAULT NULL,
  PRIMARY KEY (`rowID`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (117,'Gary Gross','eightyoctane@yahoo.com','2a188a79ab070f40bd723010f81c0869','391 Blue Mountain Lane','','','','',2,6,'','eightyoctane','',1291524716,'bluemountain',NULL,NULL),(156,'Gary Gross','eightyoctane@yahoo.com','e1c80488853d86ab9d6decfe30d8930f','','','','','',2,6,'','g2','',1302228393,'bluemountain',NULL,NULL),(155,'Gary Gross','eightyoctane@yahoo.com','0120a4f9196a5f9eb9f523f31f914da7','','','','','',1,3,'','g1','',1302207478,'bluemountain',NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-01-14 13:19:21
