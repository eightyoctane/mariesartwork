-- MySQL dump 10.13  Distrib 5.1.56, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: bmasite_visitors
-- ------------------------------------------------------
-- Server version	5.1.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `msg_id_fk` int(11) DEFAULT NULL,
  `u_id` smallint(5) unsigned DEFAULT NULL,
  `dtandtime` datetime NOT NULL,
  PRIMARY KEY (`com_id`),
  KEY `msg_id_fk` (`msg_id_fk`)
) ENGINE=MyISAM AUTO_INCREMENT=166 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (134,NULL,'Thanks Marie! :-)			',329,117,'2011-09-11 13:32:06'),(132,NULL,'		dsfgdfsd	',303,157,'2011-09-10 19:44:04'),(135,NULL,'	Gary,\nPhil wrote a comment yesterday to you, but do not see it here.\nKatie 		',332,124,'2011-09-12 07:16:05'),(137,NULL,'this is still a little buggy 			',334,117,'2011-09-12 10:43:51'),(138,NULL,'if it doesnt take try again',334,117,'2011-09-12 10:44:39'),(139,NULL,'punctuation seems to be a problem',334,117,'2011-09-12 10:44:58'),(140,NULL,'ill be improving over time',334,117,'2011-09-12 10:46:48'),(141,NULL,'Yes, Gary and I will be there. Thanks again for the invite.			',336,118,'2011-09-12 15:01:58'),(151,NULL,'	thank you volkswagon - the intermediate bike trail is great fun 3miles 		',347,117,'2011-09-20 15:06:57'),(143,NULL,'works on blackberry 			',341,117,'2011-09-12 21:35:03'),(144,NULL,'Welcome John and Nancy!			',351,117,'2011-09-18 08:34:36'),(146,NULL,'The Mezzeta came from Fresh Market in Chat			',354,117,'2011-09-19 18:10:26'),(147,NULL,'today we did harrison bay and it was four and a half miles of pure fun 			',347,117,'2011-09-20 15:02:17'),(148,NULL,'for me its like flying - always different ',347,117,'2011-09-20 15:02:44'),(149,NULL,'	works on ipad		',341,117,'2011-09-20 15:04:06'),(150,NULL,'	works on microsoft mobile (opera)		',341,117,'2011-09-20 15:04:55'),(152,NULL,'As we remember 911, it also reminds us what a privilege it is to fly general aviation in the United States 			',313,117,'2011-09-20 15:09:17'),(153,NULL,'More than just today, the lingering effects were amplified during our recent trip to Groton in the Bonanza',313,117,'2011-09-20 15:09:54'),(156,NULL,'Ok need to explain a bit - each resident keeps theirs uptodate :-)			',356,117,'2011-09-20 16:08:52'),(157,NULL,'that is also the account settings button in the menu above			',358,117,'2011-09-20 16:12:11'),(158,NULL,'	Marie and I tried to seed the list to get things started		',356,117,'2011-09-20 16:12:56'),(159,NULL,'Next time we come over we ll seed some more if resident owners are missing :)			',356,117,'2011-09-20 16:16:07'),(160,NULL,'Yes.\n			',359,118,'2011-09-20 16:34:24'),(161,NULL,'back to work! its an art repro extravaganza today!			',365,117,'2011-10-03 07:50:57'),(162,NULL,'With 3 (is my current max out of BMA) halve the cost pp to 40!		',366,117,'2011-10-03 07:56:12'),(163,NULL,'Wonderful - is it move in time?			',372,117,'2011-10-10 19:53:45'),(164,NULL,'	Let us know if we can be of any assistance in the unpacking?		',372,118,'2011-10-10 20:14:37'),(165,NULL,'	...or to work in the back room on the computer!		',373,117,'2011-10-11 11:34:16');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `rowID` smallint(5) unsigned DEFAULT NULL,
  `message` varchar(200) DEFAULT NULL,
  `u_id` smallint(5) unsigned DEFAULT NULL,
  `dtandtime` datetime NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=374 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (356,NULL,'Gary: I checked the resident list and you may need to update. I sent Marie a new list yesterday. Thanks for all your work. Katie ',124,'2011-09-20 15:46:57'),(313,NULL,'Remembering 9/11 today',117,'2011-09-11 06:13:23'),(329,NULL,'Just want to tell you how excited I am about this Blue Mountain. Thank you Gary for your countless hours putting this website together for the future of Blue Mountain Airpark.',118,'2011-09-11 13:10:33'),(311,NULL,'R/C Helicopters over Blue Mountain Airpark! http://www.youtube.com/watch?v=Jx9mTRH4_kk',117,'2011-09-10 20:34:50'),(330,NULL,'Phil and I have been exploring RC Helicopters lately, interested?',117,'2011-09-12 03:31:29'),(332,NULL,'Still having some issues with this new wall software - let me know if you have problems',117,'2011-09-12 03:37:40'),(333,NULL,'You can disable email notifications in your accout settings',117,'2011-09-12 03:57:41'),(334,NULL,'Gary,\nPhil wrote a comment yesterday, but do not see it here.\nKatie',124,'2011-09-12 07:15:54'),(335,NULL,'It is a beautiful day here at the Blue Mountain Airpark.',118,'2011-09-12 11:39:27'),(336,NULL,'Burgers at 6:30',124,'2011-09-12 13:36:42'),(359,NULL,'Gary: I am not sure what you mean. I am thinking that each person needs to update their own information. Is that correct? ',124,'2011-09-20 16:27:59'),(358,NULL,'You can make your resident info accurate for others to use at http://www.bluemountainairpark.com/Pub2/login/accountEdit.php',117,'2011-09-20 16:11:22'),(347,NULL,'after meeting some local folks who love biking - we are hooked - but for us its mountain biking',117,'2011-09-15 11:28:55'),(341,NULL,'Looks good...',154,'2011-09-12 21:07:30'),(346,NULL,'What a beautiful day we have been blessed with today!',118,'2011-09-14 10:28:52'),(344,NULL,'If you re interested you can try it at this link or we ll show you how http://www.bluemountainairpark.com/Pub2/login/recipebook/index.php ',117,'2011-09-13 15:50:36'),(345,NULL,'We ve had a recipe database at our website for some time and as far as I know marie and I are the only ones using it',117,'2011-09-13 16:13:11'),(360,NULL,'WHEW! I just finished a 4 and half hour art lesson!!!! Betty is determined to do a painting of each of her granchildren.  We have 6 and half more to go!',118,'2011-09-20 16:35:20'),(352,NULL,'It is an exceptionally beautiful morning here at Blue Mountain.  The air is crisp and clean! The sky is a beautiful cobalt blue shade with some whispy white clouds',118,'2011-09-18 08:35:54'),(351,NULL,'I am so excited that Nancy and John moved in! Now we have more neighbors!  YEAH!!!!\n',118,'2011-09-18 08:32:48'),(353,NULL,'Oh man! Marie made the best Black Beans and Rice dinner tonight!',117,'2011-09-19 17:43:33'),(354,NULL,'Check out the Black Beans and Rice recipe at \nhttp://www.bluemountainairpark.com/Pub2/login/recipebook/index.php?m=recipes',117,'2011-09-19 17:45:10'),(355,NULL,'hey did you know that you can get a printer friendly list of residents? http://www.bluemountainairpark.com/Pub2/login/listResidentsPF.php',117,'2011-09-20 14:54:42'),(362,NULL,'Now for a little reward. Headed to Don Lolo.  Any one want to come along let me know?',118,'2011-09-20 16:37:33'),(363,NULL,'WOW! What a delicious meal last night at Don Lolo.  It was fun having a double date with Katie and Phil.  I highly recommend the fajita salad!  YUMMY!',118,'2011-09-21 08:12:19'),(364,NULL,'I wish everyone at Blue Mountain Airpark a very \"HAPPY\" day.',118,'2011-09-21 08:13:14'),(365,NULL,'What a cooool morning here at Blue Mountain.  ',118,'2011-10-03 07:48:57'),(366,NULL,'Anyone want to go for a Banana flight? I can do it for the cost of gass and oil $80/hr! ',117,'2011-10-03 07:55:15'),(367,NULL,'crazy mountain bike ride at bookerTWashington today',117,'2011-10-04 20:22:25'),(368,NULL,'Anyone with ideas for a short breakfast flight (<30min)?',124,'2011-10-05 19:11:26'),(369,NULL,'Wow! Wish all the lot owners could be here to see how beautiful the runway looks.  Hope everyone is enjoying the Fall weather.\n',118,'2011-10-06 07:39:54'),(370,NULL,'Last nigh we saw Venus so brightly shining as well as the moon, it is so nice to live in Blue Mountain! Day or night! HA HA',118,'2011-10-06 07:40:55'),(371,NULL,'You now agree to the landing waver at the time you register with the BMA website',117,'2011-10-10 17:20:17'),(372,NULL,'The unpacking has begun.',179,'2011-10-10 19:04:29'),(373,NULL,'Rain, Rain, Rain--Beautiful day to paint in the hangar!',118,'2011-10-11 11:32:17');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `rowID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `email` varchar(55) NOT NULL DEFAULT '',
  `pwd` varchar(32) NOT NULL DEFAULT '',
  `add_street` varchar(80) DEFAULT NULL,
  `add_city` varchar(80) DEFAULT NULL,
  `add_state` varchar(80) DEFAULT NULL,
  `add_country` varchar(80) DEFAULT NULL,
  `add_zip` varchar(20) DEFAULT NULL,
  `u_type` tinyint(4) NOT NULL DEFAULT '0',
  `u_priv` tinyint(4) NOT NULL DEFAULT '0',
  `add_apt` varchar(80) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `start_date` int(11) DEFAULT NULL,
  `login_type` varchar(20) DEFAULT NULL,
  `sstartid` bigint(20) DEFAULT NULL,
  `last_access` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `e_notify` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`rowID`)
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (117,'Gary Gross','eightyoctane@yahoo.com','768a7b74b3f9fe2194fbc17efd1876e6','','','','','',2,6,'','eightyoctane','',1291524716,'bluemountain',NULL,NULL,'active',1),(118,'Marie House','mariesartwork@yahoo.com','b1a4041c3de5df34d3bd3d469928ccaf','','Trion','ga','USA','30753',2,4,'391 Blue Mountain Lane','mariesartwork','423-605-4483',1291562929,'bluemountain',NULL,NULL,'active',1),(124,'Phil Dater','pkdater@mindspring.com','8cad04b6c598dfe96fade4a53217be2f','471  Blue Mountain Lane','Trion','GA','USA','30753',2,4,'','planeview','706 639 9334',1291673431,'bluemountain',NULL,NULL,'active',1),(147,'John Bertrand','wingsongaviation@gmail.com','eebeedfdd07b1194d5d2defbfb986195','','Murfreesboro','TN','USA','37127',2,1,'101 Woodbiury St.','jbertran','615 818 2764',1294796941,'bluemountain',NULL,NULL,'active',1),(127,'daniel budde','frmfim@comcast.net','1404b3430289074fb19dff1fed6472a5','','kennesaw','ga','us','30152',2,4,'1216 irma court','facewhack','',1291891929,'bluemountain',NULL,NULL,'active',1),(123,'alisa bigham','sambigham@aol.com','04597ebd091c61f4676e04c63cfe27fa','389 blue mountain lane','trion','ga','usa','30753',2,2,'','rivendell','706 638 3041',1291656916,'bluemountain',NULL,NULL,'active',1),(128,'KEITH THRIFT','keith.e.thrift.jr@gmail.com','92396ea1230e178474c3e19adceab849','','','','','',1,1,'','KEITH','',1291932647,'bluemountain',NULL,NULL,'active',1),(129,'Ronald Rugel','hothopper@hotmail.com','0912df50135d75c8f67a3af1978c38c8','','San Jose','CA','USA','95125',1,1,'1442 Norman Ave.','hothopper','408 267 9642',1292433978,'bluemountain',NULL,NULL,'active',1),(149,'Chris Lampe','tiger42r@juno.com','3b75b6739c4365a944f6e497cbbd27b4','','','','','',1,1,'','Tiger42R','',1295381680,'bluemountain',NULL,NULL,'active',1),(153,'Gary Venning','gvenning@logic.bm','f62eae2d097821cf6afb741926408391','','Hamilton ','','Bermuda','HM CX',2,1,'P O Box HM 484','gvenning','4412955297',1300104362,'bluemountain',NULL,NULL,'active',1),(154,'Philip Pecoulas','ppecoulas@yahoo.com','12dda62beace2b053ee392e8e8f94f24','','','','','',2,5,'','ppecoul','813 361 6955',1301933447,'bluemountain',NULL,NULL,'active',0),(155,'Charles Aaron','cubdriverj3@windstream.net','31688572580a6b4cc60b06855ceb34e2','','Chatsworth','Georgia','USA','30705',1,1,'42 Loughridge Rd.','charlieaileron','706-280-9550',1303600055,'bluemountain',NULL,NULL,'active',1),(174,'Quinn Ahrens','qahrens@yahoo.com','1f47ade1f09f62eb25ce2889c130581e','','','','','',2,1,'','qahrens','',1315815499,'bluemountain',NULL,NULL,'active',1),(168,'Gary Gross','eightyoctane@yahoo.com','26744aa9d6c04c246957fb97d987546c','','','','','',3,7,'','contractor','',1312539608,'bluemountain',NULL,NULL,'active',0),(175,'Diana Ahrens','diana_ahrens@yahoo.com','01ed103a96a0e158e9b30ffa0ac0ed65','','','','','',2,1,'','dahrens','',1315815796,'bluemountain',NULL,NULL,'active',1),(171,'James Rutherford','canterpiroutte@comcast.net','0458856d95f040baf6f3618b7fa37555','','','','','',2,1,'','rutherford','',1315768271,'bluemountain',NULL,NULL,'active',1),(172,'Charles Taylor','ctaylor377@yahoo.com','2bd3c5187b8ea6a4dfd8b94b7226e9c9','','','','','',1,1,'','taylor','',1315768501,'bluemountain',NULL,NULL,'active',1),(173,'Scott Langton','scottlangtondvm@hotmail.com','61fadf19a0b0afe89450f858323436ac','','','','','',2,1,'','langton','',1315768735,'bluemountain',NULL,NULL,'active',1),(176,'Sarah Hughes','sagnellae@aim.com','d4b23fc47ea7d518deaf6fff6f6904f6','','','','','',2,2,'','sagnellae','',1315816040,'bluemountain',NULL,NULL,'active',0),(177,'Don Folley','cndf@cox.net','b6290f2ee8f09ceeeab7d4709645f5ca','','','','','',2,1,'','dfolley','',1316021739,'bluemountain',NULL,NULL,'inactive',1),(178,'Tim Hughes','anyelectric1@comcast.net','d4b23fc47ea7d518deaf6fff6f6904f6','','','','','',2,2,'','thughes','',1316353045,'bluemountain',NULL,NULL,'active',1),(179,'Nancy Bertrand','nancyparksbertrand@gmail.com','98b7772b1fd8c1427e5c8db8f3ebb2c9','','','','','',2,1,'','nbertrand','',1316612052,'bluemountain',NULL,NULL,NULL,1),(180,'Brent Bigham','brentbigham1@yahoo.com','88a3cf055778b6aa9901ec2ea3a2319d','','','','','',2,2,'','brentbigham1','',1316612413,'bluemountain',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-11 13:03:46
