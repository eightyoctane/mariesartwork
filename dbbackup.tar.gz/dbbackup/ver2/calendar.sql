-- MySQL dump 10.13  Distrib 5.1.56, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: bmasite_calendar
-- ------------------------------------------------------
-- Server version	5.1.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ltw_categoryv4`
--

DROP TABLE IF EXISTS `ltw_categoryv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_categoryv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `fgcolor` char(8) NOT NULL DEFAULT '#000000',
  `bgcolor` char(8) NOT NULL DEFAULT '#ffffff',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_categoryv4`
--

LOCK TABLES `ltw_categoryv4` WRITE;
/*!40000 ALTER TABLE `ltw_categoryv4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ltw_categoryv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltw_eventsv4`
--

DROP TABLE IF EXISTS `ltw_eventsv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_eventsv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `event_date` date NOT NULL DEFAULT '0000-00-00',
  `start_time` time NOT NULL DEFAULT '00:00:00',
  `end_time` time NOT NULL DEFAULT '00:00:00',
  `description` text NOT NULL,
  `recurring` tinyint(4) NOT NULL DEFAULT '0',
  `recur_dayofweek` tinyint(4) DEFAULT NULL,
  `day_event` tinyint(4) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL DEFAULT '1',
  `event_end` date NOT NULL DEFAULT '0000-00-00',
  `location` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_date` (`event_date`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_eventsv4`
--

LOCK TABLES `ltw_eventsv4` WRITE;
/*!40000 ALTER TABLE `ltw_eventsv4` DISABLE KEYS */;
INSERT INTO `ltw_eventsv4` VALUES (1,'Bigham Pancake Dinner','2010-12-07','18:00:00','20:00:00','Original arrangements made via email',0,NULL,0,0,'2010-12-07',''),(3,'Katie&Phil EggNog&Potluck','2010-12-11','17:00:00','20:00:00','',0,NULL,0,0,'2010-12-11','The Daters'),(4,'Annual Meeting!','2011-02-05','11:00:00','15:00:00','Common Area (Dater’s House if weather does not cooperate).',0,NULL,0,0,'2011-02-05','Dater\'s'),(5,'BMA Work Day','2011-03-12','09:00:00','17:00:00','Attack the moles!',0,NULL,1,0,'2011-03-12','Daters'),(6,'BMA Work Day','2011-03-26','01:00:00','01:00:00','Attack the moles deux!',0,NULL,1,0,'2011-03-26',''),(7,'P2s Fly In - cookout day!','2011-04-02','01:00:00','01:00:00','',0,NULL,1,0,'2011-04-02','BMA'),(8,'Tentative BMA Fly In','2011-06-04','01:00:00','01:00:00','Campouts Welcome!',0,NULL,1,0,'2011-06-04','BMA'),(10,'Philip\\\'s Fly-IN','2011-03-31','01:00:00','17:00:00','',0,NULL,1,0,'2011-04-03','BMA');
/*!40000 ALTER TABLE `ltw_eventsv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltw_logv4`
--

DROP TABLE IF EXISTS `ltw_logv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_logv4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `occured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` varchar(20) DEFAULT NULL,
  `info` text,
  PRIMARY KEY (`id`),
  KEY `idx_occured` (`occured`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_logv4`
--

LOCK TABLES `ltw_logv4` WRITE;
/*!40000 ALTER TABLE `ltw_logv4` DISABLE KEYS */;
INSERT INTO `ltw_logv4` VALUES (1,1,'2010-12-07 11:20:20','','<b>Login</b>: User admin login ok'),(2,3,'2010-12-07 11:23:06','admin','<B>Event: Added</b><br>Name: Pancake Dinner @ the Bigham\\\\\\\'s<br>Location: <br>Event_date: 2010-12-07<br>Start_time: 18:00:00<br>Event_end: 2010-12-07<br>End_time: 20:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>Original arrangements made via email'),(3,3,'2010-12-07 11:24:10','admin','<b>Event: Updated</b> Pancake Dinner @ the Bigham\\(1)<br>Name: Pancake Dinner @ the Bigham\\->Bigham Pancake Dinner<br>'),(4,3,'2010-12-07 11:25:50','admin','<B>Event: Added</b><br>Name: testevent<br>Location: Community Area<br>Event_date: 2010-12-07<br>Start_time: 10:00:00<br>Event_end: 2010-12-07<br>End_time: 10:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>test hyperlink:\r\nhttp://www.bluemountainairpark.com '),(5,3,'2010-12-07 11:28:14','admin','<b>Event:  Deleted</b>(2)<br>Name: testevent<br>Location: Community Area<br>Event_date: 2010-12-07<br>Event_end: 2010-12-07<br>Start_time: 10:00:00<br>End_time: 10:00:00<br>Day_event: 0<br>Recurring: 0<br>Category: <br>Description: test hyperlink:\r\nhttp://www.bluemountainairpark.com '),(6,1,'2010-12-07 11:50:51','admin','<b>User: Add katie</b><br>Password set<br>Last_Pw_Change: 2010-12-07 04:0:51<br>Email: pkdater@mindspring.com<br>Locked Status: Off<br>Change Pw Status: Off<br>Read Priv: On<br>Edit Priv: On<br>Email Priv: On<br>Logs Priv: Off<br>Admin Priv: Off<br>'),(7,1,'2010-12-07 12:09:40','','<b>Login</b>: User admin logged out'),(8,1,'2010-12-07 12:10:29','','<b>Login</b>: User katie login ok'),(9,1,'2010-12-07 12:10:44','','<b>Login</b>: User katie logged out'),(10,1,'2010-12-07 14:05:42','','<b>Login</b>: User katie login ok'),(11,1,'2010-12-07 14:06:09','','<b>Login</b>: User katie logged out'),(12,1,'2010-12-08 10:49:17','','<b>Login</b>: User katie login ok'),(13,1,'2010-12-08 10:56:33','','<b>Login</b>: User katie logged out'),(14,1,'2010-12-08 10:58:50','','<b>Login</b>: User admin login ok'),(15,1,'2010-12-08 11:01:14','admin','<b>User: Add anybody</b><br>Password set<br>Last_Pw_Change: 2010-12-08 04:0:14<br>Locked Status: Off<br>Change Pw Status: Off<br>Read Priv: On<br>Edit Priv: On<br>Email Priv: Off<br>Logs Priv: Off<br>Admin Priv: Off<br>'),(16,1,'2010-12-08 11:01:37','','<b>Login</b>: User admin logged out'),(17,1,'2010-12-08 11:47:20','','<b>Login</b>: User anybody login ok'),(18,1,'2010-12-08 14:38:31','','<b>Login</b>: User anybody login ok'),(19,1,'2010-12-11 12:48:03','','<b>Login</b>: User admin login ok'),(20,3,'2010-12-11 12:49:55','admin','<B>Event: Added</b><br>Name: Katie&Phil EggNog&Potluck<br>Location: The Daters<br>Event_date: 2010-12-11<br>Start_time: 17:00:00<br>Event_end: 2010-12-11<br>End_time: 20:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>'),(21,1,'2010-12-11 12:50:32','','<b>Login</b>: User admin logged out'),(22,1,'2010-12-11 12:50:57','','<b>Login</b>: User anybody login ok'),(23,1,'2010-12-11 12:52:12','','<b>Login</b>: User anybody logged out'),(24,1,'2011-01-09 21:51:46','','<b>Login</b>: bad username: bmaresident'),(25,1,'2011-01-09 21:54:18','','<b>Login</b>: bad username: eightyoctane'),(26,1,'2011-01-09 21:54:27','','<b>Login</b>(1): bad password for admin'),(27,1,'2011-01-09 21:54:33','','<b>Login</b>(2): bad password: admin->admin'),(28,1,'2011-01-09 22:49:22','','<b>Login</b>: User anybody login ok'),(29,3,'2011-01-09 22:50:30','anybody','<B>Event: Added</b><br>Name: Board Meeting!<br>Location: <br>Event_date: 2011-02-05<br>Start_time: 01:00:00<br>Event_end: 2011-02-05<br>End_time: 01:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>'),(30,3,'2011-01-09 22:51:46','anybody','<b>Event: Updated</b> Board Meeting!(4)<br>Start_time: 01:00:00->13:00:00<br>End_time: 01:00:00->15:00:00<br>'),(31,1,'2011-01-09 22:52:19','','<b>Login</b>: User anybody logged out'),(32,1,'2011-01-11 19:10:02','','<b>Login</b>: User anybody login ok'),(33,1,'2011-01-11 19:11:01','','<b>Login</b>: User anybody logged out'),(34,1,'2011-01-16 18:53:23','','<b>Login</b>: User anybody login ok'),(35,3,'2011-01-16 18:55:24','anybody','<b>Event: Updated</b> Board Meeting!(4)<br>Name: Board Meeting!->Annual Meeting!<br>Location: ->Dater\\\'s<br>Start_time: 13:00:00->11:00:00<br>Description: ->We\\\'re actually not complete on the start time yet. Both 11 am and 1pm are being discussed.<br>'),(36,1,'2011-01-19 13:11:01','','<b>Login</b>: User anybody login ok'),(37,3,'2011-01-19 13:11:29','anybody','<b>Event: Updated</b> Annual Meeting!(4)<br>Description: We\'re actually not complete on the start time yet. Both 11 am and 1pm are being discussed.->Common Area (Dater’s House if weather does not cooperate).<br>'),(38,1,'2011-02-05 16:24:53','','<b>Login</b>: User anybody login ok'),(39,3,'2011-02-05 16:26:43','anybody','<B>Event: Added</b><br>Name: BMA Work Day<br>Location: Daters<br>Event_date: 2011-03-12<br>Start_time: 09:00:00<br>Event_end: 2011-03-12<br>End_time: 17:00:00<br>Day_event: 1<br>Recurring: 0<br>Description:<br>Attack the moles!'),(40,3,'2011-02-05 16:27:35','anybody','<B>Event: Added</b><br>Name: BMA Work Day<br>Location: <br>Event_date: 2011-03-26<br>Start_time: 01:00:00<br>Event_end: 2011-03-26<br>End_time: 01:00:00<br>Day_event: 1<br>Recurring: 0<br>Description:<br>Attack the moles deux!'),(41,3,'2011-02-05 18:05:24','anybody','<B>Event: Added</b><br>Name: Phillip\\\'s Fly In<br>Location: BMA<br>Event_date: 2011-04-02<br>Start_time: 01:00:00<br>Event_end: 2011-04-02<br>End_time: 01:00:00<br>Day_event: 1<br>Recurring: 0<br>Description:<br>'),(42,3,'2011-02-05 18:07:28','anybody','<B>Event: Added</b><br>Name: Tentative BMA Fly In<br>Location: BMA<br>Event_date: 2011-06-04<br>Start_time: 01:00:00<br>Event_end: 2011-06-04<br>End_time: 01:00:00<br>Day_event: 1<br>Recurring: 0<br>Description:<br>Campouts Welcome!'),(43,1,'2011-03-07 16:18:04','','<b>Login</b>: bad username: eghtyoctane'),(44,1,'2011-03-07 16:18:22','','<b>Login</b>: bad username: eightyoctane'),(45,1,'2011-03-07 16:19:38','','<b>Login</b>(1): bad password for anybody'),(46,1,'2011-03-07 16:19:52','','<b>Login</b>: User anybody login ok'),(47,3,'2011-03-07 16:21:01','anybody','<B>Event: Added</b><br>Name: BMA Fly-in<br>Location: <br>Event_date: 2011-09-11<br>Start_time: 10:00:00<br>Event_end: 2011-09-11<br>End_time: 20:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>'),(48,3,'2011-03-07 16:21:23','anybody','<b>Event: Updated</b> BMA Fly-in(9)<br>Event_date: 2011-09-11->2011-09-10<br>'),(49,1,'2011-03-09 03:13:21','','<b>Login</b>: User anybody login ok'),(50,3,'2011-03-09 03:14:13','anybody','<b>Event: Updated</b> BMA Fly-in(9)<br>'),(51,3,'2011-03-09 03:14:20','anybody','<b>Event:  Deleted</b>(9)<br>Name: BMA Fly-in<br>Location: <br>Event_date: 2011-09-10<br>Event_end: 2011-09-11<br>Start_time: 10:00:00<br>End_time: 20:00:00<br>Day_event: 0<br>Recurring: 0<br>Category: <br>Description: '),(52,1,'2011-03-09 15:19:34','','<b>Login</b>: User anybody login ok'),(53,3,'2011-03-09 15:20:58','anybody','<b>Event: Updated</b> Phillip\'s Fly In(7)<br>Name: Phillip\'s Fly In->Phillip\\\'s Fly In - cookout day!<br>'),(54,3,'2011-03-09 15:21:27','anybody','<b>Event: Updated</b> Phillip\'s Fly In - cookout da(7)<br>Name: Phillip\'s Fly In - cookout da->P2s Fly In - cookout da<br>'),(55,3,'2011-03-09 15:21:45','anybody','<b>Event: Updated</b> P2s Fly In - cookout da(7)<br>Name: P2s Fly In - cookout da->P2s Fly In - cookout day!<br>'),(56,3,'2011-03-09 15:23:07','anybody','<B>Event: Added</b><br>Name: Philip\\\'s Fly-IN<br>Location: BMA<br>Event_date: 2011-03-31<br>Start_time: 01:00:00<br>Event_end: 2011-04-03<br>End_time: 17:00:00<br>Day_event: 1<br>Recurring: 0<br>Description:<br>'),(57,1,'2011-04-16 14:22:49','','<b>Login</b>: bad username: eightyoctane'),(58,1,'2011-04-16 14:23:14','','<b>Login</b>: bad username: eightyoctane'),(59,1,'2011-04-16 14:24:56','','<b>Login</b>: User anybody login ok'),(60,3,'2011-04-16 14:27:28','anybody','<B>Event: Added</b><br>Name: BMA Dues<br>Location: <br>Event_date: 2011-04-01<br>Start_time: 01:00:00<br>Event_end: 2011-04-16<br>End_time: 01:00:00<br>Day_event: 0<br>Recurring: 0<br>Description:<br>'),(61,3,'2011-04-16 14:27:56','anybody','<b>Event:  Deleted</b>(11)<br>Name: BMA Dues<br>Location: <br>Event_date: 2011-04-01<br>Event_end: 2011-04-16<br>Start_time: 01:00:00<br>End_time: 01:00:00<br>Day_event: 0<br>Recurring: 0<br>Category: <br>Description: '),(62,1,'2011-04-16 14:28:12','','<b>Login</b>: User anybody logged out'),(63,1,'2011-08-22 18:10:24','','<b>Login</b>: bad username: ggross'),(64,1,'2011-08-22 18:18:17','','<b>Login</b>: User anybody login ok'),(65,1,'2011-08-22 18:18:17','','<b>Login</b>: anybody, <b>password expired</b>.<br>Set USCHGPW'),(66,1,'2011-08-22 18:19:07','','<b>Login</b>: User anybody login ok'),(67,1,'2011-08-22 18:19:07','','<b>Login</b>: anybody, <b>password expired</b>.<br>Set USCHGPW'),(68,1,'2011-08-22 18:21:09','anybody','<b>User:</b> anybody changed password'),(69,1,'2011-08-22 18:21:45','anybody','<b>User:</b> anybody changed password');
/*!40000 ALTER TABLE `ltw_logv4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltw_usersv4`
--

DROP TABLE IF EXISTS `ltw_usersv4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltw_usersv4` (
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '0',
  `privledges` int(11) NOT NULL DEFAULT '1',
  `bad_logins` int(11) NOT NULL DEFAULT '0',
  `bad_logins_start` char(15) DEFAULT NULL,
  `last_pw_change` datetime DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltw_usersv4`
--

LOCK TABLES `ltw_usersv4` WRITE;
/*!40000 ALTER TABLE `ltw_usersv4` DISABLE KEYS */;
INSERT INTO `ltw_usersv4` VALUES ('admin','RbL6GIjq.wgQI','eightyoctane@yahoo.com',0,128,2,'1294610067','2010-12-07 04:00:19'),('katie','Rb39LeU3ORvFA','pkdater@mindspring.com',0,7,0,'','2010-12-07 04:00:51'),('anybody','RbYsSgLmLMC12','',0,3,0,'1299514778','2011-08-22 12:01:45');
/*!40000 ALTER TABLE `ltw_usersv4` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-11 13:03:46
