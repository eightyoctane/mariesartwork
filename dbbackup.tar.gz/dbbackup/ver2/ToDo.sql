-- MySQL dump 10.13  Distrib 5.1.56, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: bmasite_ToDo
-- ------------------------------------------------------
-- Server version	5.1.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tdl_items`
--

DROP TABLE IF EXISTS `tdl_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tdl_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_desc` text NOT NULL,
  `item_tags` text NOT NULL,
  `item_priority` int(11) NOT NULL,
  `item_added` varchar(45) NOT NULL,
  `item_status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tdl_items`
--

LOCK TABLES `tdl_items` WRITE;
/*!40000 ALTER TABLE `tdl_items` DISABLE KEYS */;
INSERT INTO `tdl_items` VALUES (21,'Landing Strip - Lights - clean top of lights - last completed 4/2/11 Katie, Phil, Marie, Gary','',0,'March 13, 2011, 8:10 am',2),(22,'Landing Strip - Lights - Investigate Battery Alternatives','',0,'March 13, 2011, 8:36 am',2),(23,'Community Area - Clean - Tree Maintenance - remove tree and stack wood - done 3/12/2011 Brent, Phil, Katie, Marie, Quinn, Diana, Dan, Denise, Gary','',0,'March 13, 2011, 8:39 am',2),(24,'Windsock - Sock - Clean - remove, clean, replace - done 3/12/2011, Phil, Dan, Brent, Gary','',0,'March 13, 2011, 8:44 am',2),(25,'Windsock - Pole - paint pole','',0,'March 13, 2011, 8:44 am',2),(26,'Road - Repair - fill cracks - Priority 1','',0,'March 13, 2011, 8:45 am',2),(27,'Windsock - Pole - lube bearing','',0,'March 13, 2011, 8:46 am',2),(28,'Windsock - Sock - purchase new sock - 3/15/2011 Marie found $62','',0,'March 13, 2011, 8:46 am',2),(29,'Road - Repair - purchase filler','',0,'March 13, 2011, 8:48 am',2),(30,'Road - Repair - repair road (coordinate with Bertrand project)','',0,'March 13, 2011, 8:55 am',2),(32,'Community Area - Clean - Rake Leaves - done 3/12/2011, Dan, Denise, Brent, Phil, Quinn, Diana, Marie, Gary','',0,'March 13, 2011, 8:58 am',2),(33,'Entrance - Clean - stack and remove wood - done 3/12/2011 Quinn, Diana, Katie, Marie','',0,'March 13, 2011, 8:59 am',2),(34,'Road - Clean - Edge bermuda - done 3/12/2011 - Katie, Diana, Marie, Quinn, Phil','',0,'March 13, 2011, 9:00 am',2),(35,'Fence - Repair - fix broken boards ','',0,'March 13, 2011, 9:01 am',2),(36,'Fence - Paint - purchase stain','',0,'March 13, 2011, 9:01 am',2),(37,'Fence - Paint - stain fence','',0,'March 13, 2011, 9:02 am',2),(38,'Community Area - Stage - Paint - stain stage','',0,'March 13, 2011, 9:03 am',2),(39,'Community Area - Stage - purchase stain','',0,'March 13, 2011, 9:03 am',2),(40,'Community Area - Tables - Paint - purchase stain','',0,'March 13, 2011, 9:04 am',2),(41,'Community Area - Tables - stain tables','',0,'March 13, 2011, 9:04 am',2),(42,'Community Area - Chairs - purchase paint','',0,'March 13, 2011, 9:05 am',2),(43,'Community Area - Chairs - paint chairs','',0,'March 13, 2011, 9:06 am',2),(44,'Entrance - enhance entrance','',0,'March 13, 2011, 9:06 am',2),(45,'Gate - Paint - purchase paint','',0,'March 13, 2011, 9:07 am',2),(46,'Gate - paint gate (iron)','',0,'March 13, 2011, 9:07 am',2),(47,'Road - Paint - paint stop/hold at runway','',0,'March 13, 2011, 9:08 am',2),(48,'Mower - Maintenance - mower maintenance','',0,'March 13, 2011, 9:09 am',2),(49,'Website - add To Do List - done - version1 3/12/2011 gary did it','',0,'March 13, 2011, 10:01 am',2),(50,'Website - move resident photos to internal news page - done 4/5/11 gary','',0,'April 5, 2011, 1:52 pm',2),(51,'','',0,'April 16, 2011, 8:18 am',2),(52,'Website - Add About Section','',0,'July 17, 2011, 5:26 am',2),(54,'','',0,'September 1, 2011, 12:16 pm',1);
/*!40000 ALTER TABLE `tdl_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tdl_tags`
--

DROP TABLE IF EXISTS `tdl_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tdl_tags` (
  `tags_id` int(11) NOT NULL AUTO_INCREMENT,
  `tags_tags` text NOT NULL,
  `id_item` int(11) NOT NULL,
  `item_status` int(10) NOT NULL,
  PRIMARY KEY (`tags_id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tdl_tags`
--

LOCK TABLES `tdl_tags` WRITE;
/*!40000 ALTER TABLE `tdl_tags` DISABLE KEYS */;
INSERT INTO `tdl_tags` VALUES (42,'Landing',22,2),(43,'Strip',22,2),(53,'',27,2),(57,'',29,2),(63,'',30,2),(70,'purchase',36,2),(71,'paint',36,2),(72,'',37,2),(75,'Stage',39,2),(76,'',40,2),(77,'Tables',41,2),(78,'',42,2),(79,'',43,2),(80,'entrance',44,2),(81,'enhance',44,2),(82,'gate',45,2),(84,'',47,2),(85,'Maintenance',48,2),(89,'',32,2),(91,'',23,2),(92,'',34,2),(94,'Website',49,2),(95,'',33,2),(96,'',24,2),(100,'',28,2),(110,'',50,2),(111,'',51,2),(112,'',52,2),(113,'Road',26,2),(114,'repair',26,2),(115,'Priority',26,2),(116,'',46,2),(118,'Windsock',54,1),(119,'',38,2),(120,'Lights',21,2),(121,'Clean',21,2),(124,'Fence',35,2),(127,'Windsock',25,2),(128,'Pole',25,2);
/*!40000 ALTER TABLE `tdl_tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-11 13:03:46
