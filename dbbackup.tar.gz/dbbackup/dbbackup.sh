#!/bin/sh 
rm *.sql
mysqldump -ubmasite_admin -p1200 bmasite_ToDo >ToDo.sql
mysqldump -ubmasite_admin -p1200 bmasite_calendar >calendar.sql
mysqldump -ubmasite_admin -p1200 bmasite_fbwall >fbwall.sql
mysqldump -ubmasite_admin -p1200 bmasite_osamembers >osamembers.sql
mysqldump -ubmasite_admin -p1200 bmasite_phprecipedb >phprecipedb.sql
mysqldump -ubmasite_admin -p1200 bmasite_visitors >visitors.sql
mysqldump -ubmasite_admin -pgwg bmasite_dfg >dfg.sql

