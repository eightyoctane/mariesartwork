<?php
// Dezinerfolio.com - DfGallery Auto generated upgrade state config file

// IF YOU WANT TO RESET YOUR PASSWORD, PLEASE UNCOMMENT THE LINE BELOW 
// AND GOTO http://yoursite.com/dfgallery/admin/resetpassword TO RESET YOUR PASSWORD
//ONCE YOU HAVE RESET, YOUR PASSWORD, YOU WILL HAVE TO COMMENT THIS LINE BACK.

//$config['configured_password'] = 'dezinerfolio';



?>