<?php 
// Dezinerfolio.com - DfGallery Auto generated upgrade state config file

$config = array (
  'upgrade_version' => 2.005,
);

?>