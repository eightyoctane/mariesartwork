<?php

$config['upgrade_tasks'][] = array(
	'version' => 2.000 , 
	'file' => '2000/Task_2000_1' , 
	'description' => 'Intall the core users, and gallery module.' 
);

$config['upgrade_tasks'][] = array(
	'version' => 2.005 , 
	'file' => '2005/Task_2005_1' , 
	'description' => 'Change of Foriegn keys to cascade the records.' 
);

?>