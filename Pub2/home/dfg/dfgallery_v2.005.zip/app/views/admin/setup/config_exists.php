<?php if (! defined ( 'BASEPATH' )) exit ( 'No direct script access allowed' ); ?>
<p>database.php exists.<br />
If you want to re-install the gallery then you must delete the
database.php and recreate the file with write permissions, along with the tables tables for this installation.</p>