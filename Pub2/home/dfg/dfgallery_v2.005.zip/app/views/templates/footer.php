<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
            <div class="clear"></div>
        </div>
	    <div class="footer">dfGallery <?php echo $version ?> - by <a href="http://dezinerfolio.com">DezinerFolio.com</a></div>
    </div>
</div>
</body>
</html>