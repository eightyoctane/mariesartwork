<?php if (! defined ( 'BASEPATH' )) exit ( 'No direct script access allowed' ); ?>
<?php if (isset($text)){ echo $text; } ?>