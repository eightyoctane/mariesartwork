<?php

class Welcome extends DF_Controller {
	
	function index() {
		redirect ( '/admin/gallery' );
	}

}

?>