vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Dec 2006 06:02:43 -0000
vti_author:SR|AMERICAS\\gwgross
vti_modifiedby:SR|AMERICAS\\gwgross
vti_nexttolasttimemodified:TR|24 Dec 2006 06:02:43 -0000
vti_timecreated:TR|24 Dec 2006 06:11:05 -0000
vti_extenderversion:SR|6.0.2.6551
vti_syncwith_www.eightyoctane.com\:80:TR|24 Dec 2006 06:02:43 -0000
vti_cacheddtm:TX|24 Dec 2006 06:11:05 -0000
vti_filesize:IR|157
vti_backlinkinfo:VX|
