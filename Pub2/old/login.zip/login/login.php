<?php
/* Because the authentication prompt needs to be invoked twice,
embed it within a function.
*/
function authenticate_user (){
	header('WWW-Authenticate: Basic realm="80octane Website"');
	header("HTTP/1.0 401 Unauthorized");
	exit;
}

/* If $_SERVER['PHP_AUTH_USER'] is blank, the user has not yet been prompted for the authentication information.
*/
if (!isset($_SERVER['PHP_AUTH_USER'])) {
	authenticate_user();
	
} else {
	$uname = $_SERVER["PHP_AUTH_USER"];
	$pwd = $_SERVER["PHP_AUTH_PW"];
	//echo "Input received.";
	// Connect to the MySQL database
	//mysql_connect('localhost','ggross','0pjh5r9i');
	//mysql_select_db("ggross");
	mysql_connect("localhost","artmarie_admin","g61185");
	mysql_select_db("artmarie_artmarie");

		
	// Create and execute the selection query.
	$query = "SELECT name, username, u_type, pwd FROM user
				WHERE username= '$uname' AND
				pwd=MD5('$pwd')";
	$result = mysql_query($query);
	/*
	if (get_resource_type($result) != 0) {
		echo get_resource_type($result);
	} else {
		echo "mysql_query returned resource = 0";
	}
	*/
	// If nothing was found, reprompt the user for the login information.
	if (mysql_num_rows($result) == 0) {
		echo "Unknown User.";
		authenticate_user();
	} else {
		$name = mysql_result($result, 0, "name");
		$username = mysql_result($result, 0, "username");
		$u_type = mysql_result($result, 0, "u_type");
		mail("eightyoctane@yahoo.com", "80octane user $username logged in", "Login name: $_POST[uname]\n\n");
		switch($u_type) {
			case 0:
				echo(include('./indexli.html'));
				break;
			case 1:
				//echo(include('Type1-A/index.html'));
				echo(include('./Type1-A/t1home.html'));
				break;
			case 2:
				echo(include('Type2-M/t2home.html'));
				break;
			case 3:
				echo (include('Type3-L/t3home.html'));
				break;
			case 4:
				echo (include('Type4-AJ/t4home.html'));
				break;
			default:
				echo (include('indexli.html'));
		}	
	}
}
?>