<?php
//////////////////////////////////////////////////////////////////////////// 
// ltw_footer.php 
// $Id: ltw_footer.php 5 2006-03-12 08:15:51Z mootinator $ 
// 
// ltwCalendar Sample Footer File
//////////////////////////////////////////////////////////////////////////// 

echo "
<!-- ltwCalendar Window is done -->
<!-- Close the table cell & row it is in
</td></tr>
<tr><td align=\"center\" colspan=\"2\">
Calendar provided by <a href=\"http://codewalkers.com/\" target=\"_blank\">Codewalkers</a>.
</td></tr></table>
</BODY>
</HTML>
";

?>
